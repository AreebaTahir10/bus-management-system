import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.InputMismatchException;

public class AdminModule {
    static final String USERS_FILE = "users.txt";
    static final String BOOKINGS_FILE = "booking.txt";
    static Scanner input = new Scanner(System.in);

    // ArrayLists to store admin information
    static ArrayList<String> adminId = new ArrayList<>(); // Stores admin email/IDs
    static ArrayList<String> adminPassword = new ArrayList<>(); // Stores admin passwords
    static ArrayList<String> firstNames = new ArrayList<>(); // Stores admin first names
    static ArrayList<String> lastNames = new ArrayList<>(); // Stores admin last names
    static ArrayList<String> phoneNumbers = new ArrayList<>(); // Stores admin phone numbers

    // Load admin data from file
    public static void loadAdminData() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("admins.txt"));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");

                if (parts.length == 5) {
                    // Add each part to the respective list
                    firstNames.add(parts[0]);
                    lastNames.add(parts[1]);
                    adminId.add(parts[2]);
                    adminPassword.add(parts[3]);
                    phoneNumbers.add(parts[4]);
                } else {
                    System.out.println("Skipping malformed line: " + line);
                }
            }

            // Close the file reader
            reader.close();
            System.out.println("\nAdmin data loaded successfully.\n");

        } catch (IOException e) {
            System.out.println("Error reading admin.txt: " + e.getMessage());
        }
    }

    // Save admin data to file
    public static void saveAdminDataToFile() {
        try {
            // Create a writer to overwrite "admins.txt"
            BufferedWriter writer = new BufferedWriter(new FileWriter("admins.txt"));

            for (int i = 0; i < adminId.size(); i++) {
                String line = firstNames.get(i) + "," +
                        lastNames.get(i) + "," +
                        adminId.get(i) + "," +
                        adminPassword.get(i) + "," +
                        phoneNumbers.get(i);

                writer.write(line);
                writer.newLine();
            }

            writer.close();
        } catch (IOException e) {
            System.out.println("Error saving to admins.txt: " + e.getMessage());
        }
    }

    // Lists to store bus service information
    static ArrayList<String> busServices = new ArrayList<>(); // Store Service name
    static ArrayList<String> busRoutes = new ArrayList<>(); // Stores Bus Routes
    static ArrayList<String> busFares = new ArrayList<>(); // Stores Economy Class Fare
    static ArrayList<String> busBusinessFares = new ArrayList<>(); // Stores Business Class Fare

    // Load bus data from individual service files
    public static void loadBusDataFromFiles() {
        // Array of filenames for each bus service
        String[] busFiles = {
                "daewoo_express.txt",
                "faisal_movers.txt",
                "silk_line.txt",
                "kainat_travels.txt",
                "almakkah_travels.txt"
        };

        // Corresponding service names for displaying
        String[] serviceNames = {

                "Daewoo Express",
                "Faisal Movers",
                "Silk Line",
                "Kainat Travels",
                "Al Makkah Travels"
        };

        for (int i = 0; i < busFiles.length; i++) {
            String fileName = busFiles[i];
            String serviceName = serviceNames[i];

            try {
                BufferedReader reader = new BufferedReader(new FileReader(fileName));
                String line;

                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");

                    if (parts.length == 5) {

                        // Structure: BusID, Plate, Route, Fare, BusinessFare
                        busServices.add(serviceName + " | " + parts[0] + " | Plate: " + parts[1]);
                        busRoutes.add(parts[2]);
                        busFares.add(parts[3]);
                        busBusinessFares.add(parts[4]);
                    } else {
                        System.out.println("Skipping malformed line in " + fileName + ": " + line);
                    }
                }

                reader.close();
            } catch (IOException e) {
                System.out.println("Error reading file " + fileName + ": " + e.getMessage());
            }
        }

        System.out.println("All bus service data loaded.\n");
    }

    // ---------------- USER MANAGEMENT ----------------

    static void handleUserMenu() {
        while (true) {
            System.out.println("\n--- User Management ---");
            System.out.println("1. Add User");
            System.out.println("2. Update User");
            System.out.println("3. Delete User");
            System.out.println("4. Search User by Phone");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter option: ");
            String option = input.nextLine();

            switch (option) {
                case "1":
                    addNewUser();
                    break;
                case "2":
                    updateExistingUser();
                    break;
                case "3":
                    deleteUserEntry();
                    break;
                case "4":
                    searchUserByPhone();
                    break;
                case "5":
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    static void addNewUser() {
        try {
            System.out.print("Email: ");
            String email = input.nextLine();
            if (!email.contains("@")) {
                System.out.println("Invalid email.");
                return;
            }

            System.out.print("Password: ");
            String password = input.nextLine();

            System.out.print("First Name: ");
            String firstName = input.nextLine();

            System.out.print("Last Name: ");
            String lastName = input.nextLine();

            System.out.print("Phone (+923XXXXXXXXX): ");
            String phoneNumber = input.nextLine();
            if (!phoneNumber.matches("\\+923\\d{9}")) {
                System.out.println("Invalid phone format.");
                return;
            }

            System.out.print("Cash: ");
            String cashAmount = input.nextLine();
            Integer.parseInt(cashAmount); // validation

            FileWriter writer = new FileWriter(USERS_FILE, true);
            writer.write(email + "," + password + "," + firstName + "," + lastName + "," + phoneNumber + ","
                    + cashAmount + "\n");
            writer.close();
            System.out.println("User added successfully.");
        } catch (Exception e) {
            System.out.println("Error while adding user: " + e.getMessage());
        }
    }

    static void updateExistingUser() {
        ArrayList<String> userRecords = readLinesFromFile(USERS_FILE);
        System.out.print("Enter phone number of user to update: ");
        String targetPhone = input.nextLine();
        boolean updated = false;

        for (int i = 0; i < userRecords.size(); i++) {
            String[] userData = userRecords.get(i).split(",");
            if (userData.length == 6 && userData[4].equals(targetPhone)) {
                System.out.println("Current Record: " + userRecords.get(i));
                System.out.println("Fields: 1=Email 2=Password 3=FirstName 4=LastName 5=Phone 6=Cash");
                System.out.print("Which field to update (1-6)? ");
                int field = Integer.parseInt(input.nextLine());

                System.out.print("New value: ");
                String newValue = input.nextLine();

                if (field == 1 && !newValue.contains("@")) {
                    System.out.println("Invalid email format.");
                    return;
                }
                if (field == 5 && !newValue.matches("\\+923\\d{9}")) {
                    System.out.println("Invalid phone format.");
                    return;
                }
                if (field == 6)
                    Integer.parseInt(newValue);

                userData[field - 1] = newValue;
                userRecords.set(i, String.join(",", userData));
                updated = true;
                break;
            }
        }

        if (updated) {
            writeLinesToFile(USERS_FILE, userRecords);
            System.out.println("User updated.");
        } else {
            System.out.println("User not found.");
        }
    }

    static void deleteUserEntry() {
        ArrayList<String> userRecords = readLinesFromFile(USERS_FILE);
        System.out.print("Enter phone number of user to delete: ");
        String targetPhone = input.nextLine();

        boolean deleted = userRecords.removeIf(record -> record.contains(targetPhone));
        if (deleted) {
            writeLinesToFile(USERS_FILE, userRecords);
            System.out.println("User deleted.");
        } else {
            System.out.println("User not found.");
        }
    }

    static void searchUserByPhone() {
        ArrayList<String> userRecords = readLinesFromFile(USERS_FILE);
        System.out.print("Enter phone number to search: ");
        String phone = input.nextLine();

        for (String record : userRecords) {
            if (record.contains(phone)) {
                System.out.println("User Found: " + record);
                return;
            }
        }
        System.out.println("User not found.");
    }

    static void viewAllUsers() {
        ArrayList<String> userRecords = readLinesFromFile(USERS_FILE);

        if (userRecords.isEmpty()) {
            System.out.println("No users found.");
            return;
        }

        System.out.println("\n--- All Users ---");
        System.out.printf("%-25s %-15s %-10s %-10s %-15s %-10s%n",
                "Email", "Password", "First Name", "Last Name", "Phone", "Cash");

        for (String record : userRecords) {
            String[] fields = record.split(",");
            if (fields.length == 6) {
                System.out.printf("%-25s %-15s %-10s %-10s %-15s %-10s%n",
                        fields[0], fields[1], fields[2], fields[3], fields[4], fields[5]);
            }
        }
    }

    // ---------------- BOOKING MANAGEMENT ----------------

    static void handleBookingMenu() {
        while (true) {
            System.out.println("\n--- Booking Management ---");
            System.out.println("1. Add Booking");
            System.out.println("2. Update Booking");
            System.out.println("3. Delete Booking");
            System.out.println("4. Search Booking");
            System.out.println("5. View All Bookings");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter option: ");
            String option = input.nextLine();

            switch (option) {
                case "1":
                    addNewBooking();
                    break;
                case "2":
                    updateExistingBooking();
                    break;
                case "3":
                    deleteBookingEntry();
                    break;
                case "4":
                    searchBookingEntry();
                    break;
                case "5":
                    viewAllBookings();
                    break;
                case "6":
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }

    static void addNewBooking() {
        try {
            System.out.print("Phone: ");
            String phone = input.nextLine();
            System.out.print("Booking ID: ");
            String bookingId = input.nextLine();
            System.out.print("Date (dd/mm/yyyy): ");
            String date = input.nextLine();
            System.out.print("Time (hh:mm): ");
            String time = input.nextLine();
            System.out.print("Payment Method: ");
            String paymentMethod = input.nextLine();
            System.out.print("Fare (PKR): ");
            String fare = input.nextLine();
            Integer.parseInt(fare); // validation
            System.out.print("Route: ");
            String route = input.nextLine();
            System.out.print("Class (Economy/Business): ");
            String ticketClass = input.nextLine();
            System.out.print("Seats: ");
            String seats = input.nextLine();
            Integer.parseInt(seats); // validation
            System.out.print("Company: ");
            String company = input.nextLine();

            String bookingRecord = phone + " | " + bookingId + " | " + date + " | " + time + " | " +
                    paymentMethod + " | " + fare + " PKR | " + route + " | " + ticketClass + " | " +
                    seats + " | " + company;

            FileWriter writer = new FileWriter(BOOKINGS_FILE, true);
            writer.write(bookingRecord + "\n");
            writer.close();
            System.out.println("Booking added.");
        } catch (Exception e) {
            System.out.println("Error while adding booking: " + e.getMessage());
        }
    }

    static void updateExistingBooking() {
        ArrayList<String> bookingRecords = readLinesFromFile(BOOKINGS_FILE);
        System.out.print("Enter Booking ID or Phone: ");
        String searchKey = input.nextLine();
        boolean updated = false;

        for (int i = 0; i < bookingRecords.size(); i++) {
            if (bookingRecords.get(i).contains(searchKey)) {
                System.out.println("Current Booking: " + bookingRecords.get(i));
                System.out.print("Enter full updated booking line: ");
                String updatedBooking = input.nextLine();
                bookingRecords.set(i, updatedBooking);
                updated = true;
                break;
            }
        }

        if (updated) {
            writeLinesToFile(BOOKINGS_FILE, bookingRecords);
            System.out.println("Booking updated.");
        } else {
            System.out.println("Booking not found.");
        }
    }

    static void deleteBookingEntry() {
        ArrayList<String> bookingRecords = readLinesFromFile(BOOKINGS_FILE);
        System.out.print("Enter Booking ID or Phone: ");
        String searchKey = input.nextLine();

        boolean deleted = bookingRecords.removeIf(record -> record.contains(searchKey));
        if (deleted) {
            writeLinesToFile(BOOKINGS_FILE, bookingRecords);
            System.out.println("Booking deleted.");
        } else {
            System.out.println("Booking not found.");
        }
    }

    static void searchBookingEntry() {
        ArrayList<String> bookingRecords = readLinesFromFile(BOOKINGS_FILE);
        System.out.print("Enter Booking ID or Phone: ");
        String searchKey = input.nextLine();

        for (String record : bookingRecords) {
            if (record.contains(searchKey)) {
                System.out.println("Booking Found: " + record);
                return;
            }
        }
        System.out.println("Booking not found.");
    }

    static void viewAllBookings() {
        ArrayList<String> bookingRecords = readLinesFromFile(BOOKINGS_FILE);

        if (bookingRecords.isEmpty()) {
            System.out.println("No bookings found.");
            return;
        }

        System.out.println("\n--- All Bookings ---");
        for (String record : bookingRecords) {
            System.out.println(record);
        }
    }

    // ---------------- FILE HELPERS ----------------

    static ArrayList<String> readLinesFromFile(String filePath) {
        ArrayList<String> lines = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                lines.add(currentLine);
            }
            reader.close();
        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }
        return lines;
    }

    static void writeLinesToFile(String filePath, ArrayList<String> lines) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(filePath));
            for (String line : lines) {
                writer.write(line + "\n");
            }
            writer.close();
        } catch (Exception e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    // MAIN METHOD
    public static void run() {

        loadAdminData(); // Load data from admins.txt
        loadBusDataFromFiles(); // Load Data from buses files

        while (true) {
            int choice = -1;

            try {
                // Prompt user for login, signup, or exit
                do {
                    System.out.println("\u001b[35m");
                    System.out.println("\r\n" + //
                            "██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗    ████████╗ ██████╗ \r\n" + //
                            "██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝    ╚══██╔══╝██╔═══██╗\r\n" + //
                            "██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗         ██║   ██║   ██║\r\n" + //
                            "██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝         ██║   ██║   ██║\r\n" + //
                            "╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗       ██║   ╚██████╔╝\r\n" + //
                            " ╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝       ╚═╝    ╚═════╝ \r\n" + //
                            "                                                                                    \r\n" + //
                            "");
                    System.out.println("\r\n" + //
                            " █████╗ ██████╗ ███╗   ███╗██╗███╗   ██╗    ██████╗  █████╗ ███╗   ██╗███████╗██╗     \r\n"
                            + //
                            "██╔══██╗██╔══██╗████╗ ████║██║████╗  ██║    ██╔══██╗██╔══██╗████╗  ██║██╔════╝██║     \r\n"
                            + //
                            "███████║██║  ██║██╔████╔██║██║██╔██╗ ██║    ██████╔╝███████║██╔██╗ ██║█████╗  ██║     \r\n"
                            + //
                            "██╔══██║██║  ██║██║╚██╔╝██║██║██║╚██╗██║    ██╔═══╝ ██╔══██║██║╚██╗██║██╔══╝  ██║     \r\n"
                            + //
                            "██║  ██║██████╔╝██║ ╚═╝ ██║██║██║ ╚████║    ██║     ██║  ██║██║ ╚████║███████╗███████╗\r\n"
                            + //
                            "╚═╝  ╚═╝╚═════╝ ╚═╝     ╚═╝╚═╝╚═╝  ╚═══╝    ╚═╝     ╚═╝  ╚═╝╚═╝  ╚═══╝╚══════╝╚══════╝\r\n"
                            + //
                            "                                                                                      \r\n"
                            + //
                            "");
                    System.out.println("\u001b[0m");

                    System.out.println("--------------------------------------------------");
                    System.out.println("||            Welcome to Admin Module           ||");
                    System.out.println("--------------------------------------------------");
                    System.out.println("||                                              ||");
                    System.out.println("||              1. Login                        ||");
                    System.out.println("||              2. Signup                       ||");
                    System.out.println("||              3. Exit                         ||");
                    System.out.println("||                                              ||");
                    System.out.println("--------------------------------------------------");

                    System.out.print("Enter your choice: ");
                    choice = input.nextInt();
                    input.nextLine(); // clear buffer

                    if (choice != 1 && choice != 2 && choice != 3)
                        System.out.println("Invalid choice. Try again.");

                } while (choice != 1 && choice != 2 && choice != 3);

            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter 1, 2, or 3.");
                input.nextLine();
                continue;
            }

            if (choice == 3) {
                System.out.println("Exiting... Goodbye!");
                return;
            }

            if (choice == 1) {
                int emailIndex = -1;

                try {
                    emailIndex = login();
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input during login.");
                    input.nextLine();
                    continue;
                } catch (ArrayIndexOutOfBoundsException e) {
                    System.out.println("Login error. Please try again.");
                    continue;
                }

                if (emailIndex == -1) {
                    continue; // Go back to main menu
                }

                int postLoginChoice = -1;
                try {
                    do {
                        System.out.println("--------------------------------------------------");
                        System.out.println("||               Admin Dashboard                ||");
                        System.out.println("--------------------------------------------------");
                        System.out.println("||                                              ||");
                        System.out.println("||     1. View or Update Profile                ||");
                        System.out.println("||     2. Bus Management Menu                   ||");
                        System.out.println("||     3. User Management Menu                  ||");
                        System.out.println("||     4. Booking Management Menu               ||");
                        System.out.println("||     0. Back to Main Menu                     ||");
                        System.out.println("||                                              ||");
                        System.out.println("--------------------------------------------------");

                        System.out.print("Enter your choice: ");
                        postLoginChoice = input.nextInt();
                        input.nextLine();

                        if (postLoginChoice == 1) {
                            int profileOption = -1;
                            do {
                                System.out.println("________Profile Management________");
                                System.out.println("     ");
                                System.out.println("1. View Profile ");
                                System.out.println("2. Update Profile ");
                                System.out.println("0. Back to Admin Dashboard");
                                System.out.println("_________________________________");

                                System.out.print("Enter your choice: ");
                                profileOption = input.nextInt();
                                input.nextLine();

                                if (profileOption == 1) {
                                    viewProfile(emailIndex);
                                } else if (profileOption == 2) {
                                    updateProfile(emailIndex);
                                } else if (profileOption != 0) {
                                    System.out.println("Invalid input.");
                                }
                            } while (profileOption != 0);

                        } else if (postLoginChoice == 2) {
                            busManagementMenu();

                        } else if (postLoginChoice == 3) {
                            handleUserMenu();

                        } else if (postLoginChoice == 4) {
                            handleBookingMenu();

                        } else if (postLoginChoice != 0) {
                            System.out.println("Invalid input.");
                        }

                    } while (postLoginChoice != 0); // Back to main menu

                } catch (InputMismatchException e) {
                    System.out.println("Invalid input. Please enter a valid number.");
                    input.nextLine();
                }

            } else {
                signup(); // Signup logic
            }
        }
    }

    // -------------------------------
    // LOGIN SECTION
    // -------------------------------
    public static int login() {
        boolean emailFound = false;
        int emailIndex = -1;
        String emailId;

        // Step 1: Prompt for email until found
        try {
            do {
                System.out.print("Enter your Email ID: ");
                emailId = input.next();

                for (int i = 0; i < adminId.size(); i++) {
                    if (adminId.get(i).equals(emailId)) {
                        emailFound = true;
                        emailIndex = i;
                        break;
                    }
                }

                if (!emailFound) {
                    System.out.println("Email not found. Try again.");
                }

            } while (!emailFound);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input type. Returning to main menu...");
            input.nextLine(); // clear buffer
            return -1;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index error occurred. Returning to main menu...");
            return -1;
        }

        input.nextLine(); // Clear buffer

        // Step 2: Prompt for password (max 3 attempts)
        int attempts = 0;

        try {
            while (attempts < 3) {
                System.out.print("Enter your password: ");
                String password = input.nextLine();

                if (password.equals(adminPassword.get(emailIndex))) {
                    System.out.println("\n\t\tYou have successfully logged in!");
                    return emailIndex;

                } else {
                    attempts++;
                    if (attempts < 3) {
                        System.out.println("Wrong password. Attempts left: " + (3 - attempts));
                    }
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input type. Returning to main menu...");
            input.nextLine(); // clear buffer
            return -1;
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Index error occurred. Returning to main menu...");
            return -1;
        }

        // After 3 failed attempts
        System.out.println("Too many failed attempts. Returning to main menu...\n");
        return -1; // Login failed
    }

    // -------------------------------
    // SIGNUP SECTION
    // -------------------------------
    public static void signup() {
        try {

            // Input Admin Info
            System.out.print("Enter your First Name: ");
            String firstName = input.next();

            System.out.print("Enter your Last Name: ");
            String lastName = input.next();

            String emailId;
            do {
                System.out.print("Enter your Email ID: ");
                emailId = input.next();

                if (!emailValidation(emailId))
                    System.out.println("Invalid Email");

            } while (!emailValidation(emailId));

            input.nextLine();

            // Input Password
            String password;
            do {
                System.out.print("Enter your password: ");
                password = input.nextLine();

                if (isValidPassword(password))
                    System.out.println("Strong password!");
                else
                    System.out.println("Password must contain uppercase, lowercase, number, and special character.");
            } while (!isValidPassword(password));

            // Input Phone Number
            String phone;
            do {
                System.out.print("Enter your Phone Number (must start with +92 and be 13 digits): ");
                phone = input.nextLine();

                if (!isValidPhone(phone)) {
                    System.out.println("Invalid phone number. Try again.");
                }
            } while (!isValidPhone(phone));

            // Add to lists
            adminId.add(emailId);
            adminPassword.add(password);
            firstNames.add(firstName);
            lastNames.add(lastName);
            phoneNumbers.add(phone);

            // Save to file (append mode)
            BufferedWriter writer = new BufferedWriter(new FileWriter("admins.txt", true));
            writer.write(firstName + "," + lastName + "," + emailId + "," + password + "," + phone);
            writer.newLine();
            writer.close();

            System.out.println("Account created successfully!");

        } catch (InputMismatchException e) {
            System.out.println("Invalid input type. Signup failed.");
            input.nextLine(); // clear buffer
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Array index error occurred. Signup failed.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format. Signup failed.");
        }
    }

    // ---------------------------------------
    // View Profile Method
    public static void viewProfile(int index) {
        System.out.println("-------------------------------------------------");
        System.out.println("||                Your Profile                 ||");
        System.out.println("-------------------------------------------------");
        System.out.println("|| First Name      : " + firstNames.get(index) + "                     ||");
        System.out.println("|| Last Name       : " + lastNames.get(index) + "                     ||");
        System.out.println("|| Email           : " + adminId.get(index) + "   ||");
        if (index < phoneNumbers.size()) {
            System.out.println("|| Phone Number    : " + phoneNumbers.get(index) + "             ||");
        } else {
            System.out.println("|| Phone Number    : Not added                      ||");
        }
        System.out.println("--------------------------------------------------");
    }

    // Update Profile Method
    public static void updateProfile(int index) {
        int updateChoice = -1;
        do {
            try {
                System.out.println("\n_________Update Menu_________");
                System.out.println("1. Update Phone Number");
                System.out.println("2. Update Email");
                System.out.println("3. Update First Name");
                System.out.println("4. Update Last Name");
                System.out.println("5. Update Password");
                System.out.println("0. Exit to Profile Management");
                System.out.println("_______________________________");

                System.out.print("Enter your choice: ");
                updateChoice = input.nextInt();
                input.nextLine();

                switch (updateChoice) {
                    case 1: // Update Phone Number
                        String phone;
                        do {
                            System.out.print("Enter your new Phone Number (must start with +92 and be 13 digits): ");
                            phone = input.nextLine();
                            if (!isValidPhone(phone)) {
                                System.out.println("Invalid phone number. Try again.");
                            }
                        } while (!isValidPhone(phone));

                        if (index < phoneNumbers.size())
                            phoneNumbers.set(index, phone);
                        else
                            phoneNumbers.add(phone);

                        System.out.println("Phone number updated.");
                        saveAdminDataToFile();
                        break;

                    case 2: // Update Email
                        String newEmail;
                        do {
                            System.out.print("Enter new Email ID: ");
                            newEmail = input.next();

                            if (!emailValidation(newEmail))
                                System.out.println("Invalid Email");

                        } while (!emailValidation(newEmail));

                        adminId.set(index, newEmail);
                        System.out.println("Email updated.");
                        saveAdminDataToFile();
                        break;

                    case 3: // Update First Name
                        System.out.print("Enter new First Name: ");
                        String newFirst = input.next();
                        firstNames.set(index, newFirst);
                        System.out.println("First name updated.");
                        saveAdminDataToFile();
                        break;

                    case 4: // Update Last Name
                        System.out.print("Enter new Last Name: ");
                        String newLast = input.next();
                        lastNames.set(index, newLast);
                        System.out.println("Last name updated.");
                        saveAdminDataToFile();
                        break;

                    case 5: // Update Password
                        System.out.print("Enter your current password: ");
                        String oldPassword = input.nextLine();

                        // Check if old password is correct
                        if (!oldPassword.equals(adminPassword.get(index))) {
                            System.out.println("Incorrect current password. Password not updated.");
                            break;
                        }

                        String newPassword;

                        do {
                            System.out.print("Enter new password (no spaces allowed): ");
                            newPassword = input.nextLine();

                            // Validate new password format
                            if (newPassword.contains(" ")) {
                                System.out.println("Password cannot contain spaces.");

                            } else if (isValidPassword(newPassword)) {
                                System.out.println("Strong password!");
                                break; // valid password
                            } else {
                                System.out.println(
                                        "Password must contain uppercase, lowercase, digit, and special character.");
                            }

                        } while (true);

                        // Update password
                        adminPassword.set(index, newPassword);
                        System.out.println("Password updated.");
                        break;

                    case 0: // Exit Update Menu
                        System.out.println("\n\tExiting update menu.\n");
                        break;

                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input type. Please enter a valid number.");
                input.nextLine(); // clear buffer
                updateChoice = -1; // reset to continue loop
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: Index out of bounds while updating profile.");
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number format.");
            }
        } while (updateChoice != 0);
    }

    // ---------------------------------------
    // Email Validation
    public static boolean emailValidation(String emailId) {
        if (!emailId.contains("@"))
            return false;

        return emailId.endsWith("@gmail.com") ||
                emailId.endsWith("@outlook.com") ||
                emailId.endsWith("@yahoo.com") ||
                emailId.endsWith("@icloud.com") ||
                emailId.endsWith("@aol.com") ||
                emailId.endsWith("@zoho.com") ||
                emailId.endsWith("@gmx.com");
    }

    // ---------------------------------------
    // Password Validation
    public static boolean isValidPassword(String password) {
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        if (password.length() < 9) {
            System.out.println("Password must be at least 9 characters long.");
            return false;
        }

        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch))
                hasUpper = true;
            else if (Character.isLowerCase(ch))
                hasLower = true;
            else if (Character.isDigit(ch))
                hasDigit = true;
            else
                hasSpecial = true;
        }

        if (!hasUpper)
            System.out.println("Missing uppercase letter.");
        if (!hasLower)
            System.out.println("Missing lowercase letter.");
        if (!hasDigit)
            System.out.println("Missing digit.");
        if (!hasSpecial)
            System.out.println("Missing special character.");

        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    // ---------------------------------------
    // Phone Number Validation
    public static boolean isValidPhone(String phone) {
        // Must be exactly 13 characters: "+923XXXXXXXXX"
        if (phone.length() != 13) {
            return false;
        }

        // Must start with +92
        if (!phone.startsWith("+92")) {
            return false;
        }

        // Must have a digit 3 after +92 (i.e., mobile number: +923...)
        if (phone.charAt(3) != '3') {
            return false;
        }

        // Check that all remaining characters are digits
        for (int i = 4; i < 13; i++) {
            char ch = phone.charAt(i);
            if (ch < '0' || ch > '9') {
                return false;
            }
        }

        return true; // Passed all checks
    }

    // -------------------------------
    // BUS MANAGEMENT MENU
    // -------------------------------
    public static void busManagementMenu() {
        int busChoice = -1;
        do {
            try {
                System.out.println("--------------------------------------------------");
                System.out.println("||             Bus Management Menu              ||");
                System.out.println("--------------------------------------------------");
                System.out.println("||                                              ||");
                System.out.println("||     1. Add Bus                               ||");
                System.out.println("||     2. Update Bus                            ||");
                System.out.println("||     3. Delete Bus                            ||");
                System.out.println("||     4. View All Buses                        ||");
                System.out.println("||     0. Exit Bus Menu                         ||");
                System.out.println("||                                              ||");
                System.out.println("--------------------------------------------------");
                System.out.print("Enter your choice: ");

                busChoice = input.nextInt();
                input.nextLine(); // clear buffer

                switch (busChoice) {
                    case 1: // ADD BUS
                        System.out.println("\n___Select Bus Service:___");
                        System.out.println("1. Daewoo Express");
                        System.out.println("2. Faisal Movers");
                        System.out.println("3. Silk Line");
                        System.out.println("4. Al Makkah Travels");
                        System.out.println("5. Kainat Travels");
                        System.out.println("____________________________");

                        int serviceChoice;
                        String serviceName = "";
                        String fileName = "";

                        do {
                            // Select Bus Service
                            System.out.print("Enter your choice (1-5): ");
                            serviceChoice = input.nextInt();
                            input.nextLine();

                            switch (serviceChoice) {
                                case 1:
                                    serviceName = "Daewoo Express";
                                    fileName = "daewoo_express.txt";
                                    break;
                                case 2:
                                    serviceName = "Faisal Movers";
                                    fileName = "faisal_movers.txt";
                                    break;
                                case 3:
                                    serviceName = "Silk Line";
                                    fileName = "silk_line.txt";
                                    break;
                                case 4:
                                    serviceName = "Al Makkah Travels";
                                    fileName = "almakkah_travels.txt";
                                    break;
                                case 5:
                                    serviceName = "Kainat Travels";
                                    fileName = "kainat_travels.txt";
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        } while (serviceChoice < 1 || serviceChoice > 5);

                        // Count how many buses already exist in this file
                        int busNumber = 1;
                        try {
                            BufferedReader reader = new BufferedReader(new FileReader(fileName));
                            while (reader.readLine() != null) {
                                busNumber++;
                            }
                            reader.close();
                        } catch (IOException e) {
                            System.out.println("Error reading file to count buses: " + e.getMessage());
                            break;
                        }

                        // Enter Bus Details
                        System.out.print("Enter Plate Number: ");
                        String plateNumber = input.nextLine();

                        System.out.print("Enter Route: ");
                        String route = input.nextLine();

                        System.out.print("Enter Economy Fare: ");
                        String fare = input.nextLine();

                        System.out.print("Enter Buisness Fare: ");
                        String businessFare = input.nextLine();

                        // Format: Bus number,Service Name,Route,Economy Fare,Business Fare
                        String busLine = "Bus " + busNumber + "," + plateNumber + "," + route + "," + fare + ","
                                + businessFare;

                        try {
                            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true)); // append mode
                            writer.write(busLine);
                            writer.newLine();
                            writer.close();
                        } catch (IOException e) {
                            System.out.println("Error writing to file: " + e.getMessage());
                            break;
                        }

                        // Save Bus to txt file
                        busServices.add("Bus " + busNumber + " (" + serviceName + ")");
                        busRoutes.add(route);
                        busFares.add(fare);
                        busBusinessFares.add(businessFare);

                        System.out.println("Bus added successfully to " + fileName);
                        break;

                    case 2: // UPDATE BUS
                        System.out.println("\n___Select Bus Service to Update:___");
                        System.out.println("1. Daewoo Express");
                        System.out.println("2. Faisal Movers");
                        System.out.println("3. Silk Line");
                        System.out.println("4. Al Makkah Travels");
                        System.out.println("5. Kainat Travels");
                        System.out.println("______________________________________");

                        int updateServiceChoice = 0;
                        String selectedService = "";
                        String fileToUpdate = "";

                        do {
                            // Select Bus Service to Update
                            System.out.print("Enter your choice (1-5): ");
                            updateServiceChoice = input.nextInt();
                            input.nextLine();

                            switch (updateServiceChoice) {
                                case 1:
                                    selectedService = "Daewoo Express";
                                    fileToUpdate = "daewoo_express.txt";
                                    break;
                                case 2:
                                    selectedService = "Faisal Movers";
                                    fileToUpdate = "faisal_movers.txt";
                                    break;
                                case 3:
                                    selectedService = "Silk Line";
                                    fileToUpdate = "silk_line.txt";
                                    break;
                                case 4:
                                    selectedService = "Al Makkah Travels";
                                    fileToUpdate = "almakkah_travels.txt";
                                    break;
                                case 5:
                                    selectedService = "Kainat Travels";
                                    fileToUpdate = "kainat_travels.txt";
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        } while (updateServiceChoice < 1 || updateServiceChoice > 5);

                        // Assign the same file to both original and new (for now, until service
                        // changes)
                        String originalFile = fileToUpdate;
                        String newFileAfterServiceChange = fileToUpdate;

                        // Create an ArrayList to hold all lines (buses) from the selected file
                        ArrayList<String> busLines = new ArrayList<>();
                        try {
                            BufferedReader reader = new BufferedReader(new FileReader(fileToUpdate));
                            String line;
                            while ((line = reader.readLine()) != null) {
                                busLines.add(line);
                            }
                            reader.close();
                        } catch (IOException e) {
                            System.out.println("Error reading " + fileToUpdate + ": " + e.getMessage());
                            break;
                        }

                        // Check if there are any buses available in the selected service
                        if (busLines.isEmpty()) {
                            System.out.println("No buses available to update in " + selectedService);
                            break;
                        }

                        // Display the list of available buses in the selected service
                        System.out.println("\nAvailable Buses in " + selectedService + ":");
                        for (int i = 0; i < busLines.size(); i++) {
                            System.out.println((i + 1) + ". " + busLines.get(i));
                        }

                        // Ask user which bus they want to update
                        System.out.print("\nEnter the number of the bus you want to update: ");
                        int updateIndex = input.nextInt() - 1;
                        input.nextLine();

                        // Ask user which bus they want to update
                        if (updateIndex < 0 || updateIndex >= busLines.size()) {
                            System.out.println("Invalid bus number.");
                            break;
                        }

                        String[] parts = busLines.get(updateIndex).split(",");

                        // Check if the selected line has valid format
                        if (parts.length < 5) {
                            System.out.println("Malformed bus data. Cannot update.");
                            break;
                        }

                        System.out.println("\n_____Update Bus Info_____");
                        System.out.println("1. Change Service");
                        System.out.println("2. Update Plate Number");
                        System.out.println("3. Update Route");
                        System.out.println("4. Update Economy Fare");
                        System.out.println("5. Update Business Fare");
                        System.out.println("__________________________");

                        System.out.print("\nEnter your choice: ");
                        int updateOption = input.nextInt();
                        input.nextLine();

                        switch (updateOption) {
                            case 1: // Change Service
                                System.out.println("____Choose new Service:____");
                                System.out.println("1. Daewoo Express");
                                System.out.println("2. Faisal Movers");
                                System.out.println("3. Silk Line");
                                System.out.println("4. Al Makkah Travels");
                                System.out.println("5. Kainat Travels");
                                System.out.println("__________________________");

                                int newServiceChoice;
                                do {
                                    System.out.print("Enter choice: ");
                                    newServiceChoice = input.nextInt();
                                    input.nextLine();

                                    // Map user input to the corresponding file
                                    switch (newServiceChoice) {
                                        case 1:
                                            newFileAfterServiceChange = "daewoo_express.txt";
                                            break;
                                        case 2:
                                            newFileAfterServiceChange = "faisal_movers.txt";
                                            break;
                                        case 3:
                                            newFileAfterServiceChange = "silk_line.txt";
                                            break;
                                        case 4:
                                            newFileAfterServiceChange = "almakkah_travels.txt";
                                            break;
                                        case 5:
                                            newFileAfterServiceChange = "kainat_travels.txt";
                                            break;
                                        default:
                                            System.out.println("Invalid choice.");
                                    }
                                } while (newServiceChoice < 1 || newServiceChoice > 5);
                                break;

                            case 2: // Update Plate Number
                                System.out.print("Enter new Plate Number: ");
                                parts[1] = input.nextLine();
                                break;

                            case 3: // Update Route
                                System.out.print("Enter new Route: ");
                                parts[2] = input.nextLine();
                                break;

                            case 4: // Update Economy Fare
                                System.out.print("Enter new Economy Fare: ");
                                parts[3] = input.nextLine();
                                break;

                            case 5: // Update Business Fare
                                System.out.print("Enter new Business Fare: ");
                                parts[4] = input.nextLine();
                                break;

                            default:
                                System.out.println("Invalid option.");
                                break;
                        }

                        // Reconstruct updated bus line after changes
                        String updatedLine = parts[0] + "," + parts[1] + "," + parts[2] + "," + parts[3] + ","
                                + parts[4];

                        if (originalFile.equals(newFileAfterServiceChange)) {
                            busLines.set(updateIndex, updatedLine); // Replace the selected line
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter(originalFile)); // Overwrite
                                                                                                          // file
                                for (int i = 0; i < busLines.size(); i++) {
                                    writer.write(busLines.get(i));
                                    writer.newLine();
                                }
                                writer.close();
                                System.out.println("Bus information updated successfully.");
                            } catch (IOException e) {
                                System.out.println("Error writing to file: " + e.getMessage());
                            }

                        } else {
                            // If the service has changed, remove from old file and add to new one
                            busLines.remove(updateIndex);

                            try {
                                // Rewrite the old file without the removed bus
                                BufferedWriter writer = new BufferedWriter(new FileWriter(originalFile));
                                for (int i = 0; i < busLines.size(); i++) {
                                    writer.write(busLines.get(i));
                                    writer.newLine();
                                }
                                writer.close();

                                // Append the updated bus to the new service file
                                BufferedWriter newWriter = new BufferedWriter(
                                        new FileWriter(newFileAfterServiceChange, true));
                                newWriter.write(updatedLine);
                                newWriter.newLine();
                                newWriter.close();

                                System.out.println("Bus moved to new service and updated successfully.");
                            } catch (IOException e) {
                                System.out.println("Error moving bus to new file: " + e.getMessage());
                            }
                        }

                        break;

                    case 3: // DELETE BUS
                        System.out.println("\n_____Select Bus Service to Delete:____");
                        System.out.println("1. Daewoo Express");
                        System.out.println("2. Faisal Movers");
                        System.out.println("3. Silk Line");
                        System.out.println("4. Al Makkah Travels");
                        System.out.println("5. Kainat Travels");
                        System.out.println("_________________________________________");

                        int deleteServiceChoice = 0;
                        String fileToDeleteFrom = "";

                        do {
                            System.out.print("Enter your choice (1-5): ");
                            deleteServiceChoice = input.nextInt();
                            input.nextLine();

                            // Map the service number to the correct file name
                            switch (deleteServiceChoice) {
                                case 1:
                                    fileToDeleteFrom = "daewoo_express.txt";
                                    break;
                                case 2:
                                    fileToDeleteFrom = "faisal_movers.txt";
                                    break;
                                case 3:
                                    fileToDeleteFrom = "silk_line.txt";
                                    break;
                                case 4:
                                    fileToDeleteFrom = "almakkah_travels.txt";
                                    break;
                                case 5:
                                    fileToDeleteFrom = "kainat_travels.txt";
                                    break;
                                default:
                                    System.out.println("Invalid choice. Try again.");
                            }
                        } while (deleteServiceChoice < 1 || deleteServiceChoice > 5);

                        // Read all lines (buses) from the selected file into a list
                        ArrayList<String> busLinesToDelete = new ArrayList<>();
                        try {
                            BufferedReader reader = new BufferedReader(new FileReader(fileToDeleteFrom));
                            String line;
                            while ((line = reader.readLine()) != null) {
                                busLinesToDelete.add(line);
                            }
                            reader.close();

                        } catch (IOException e) {
                            System.out.println("Error reading " + fileToDeleteFrom + ": " + e.getMessage());
                            break;
                        }

                        // If no buses found in file
                        if (busLinesToDelete.isEmpty()) {
                            System.out.println("No buses available to delete in selected service.");
                            break;
                        }

                        // Show available buses
                        System.out.println("\nAvailable Buses:");
                        for (int i = 0; i < busLinesToDelete.size(); i++) {
                            System.out.println((i + 1) + ". " + busLinesToDelete.get(i));
                        }

                        // Ask user to choose which bus to delete
                        System.out.print("Enter the number of the bus you want to delete: ");
                        int deleteIndex = input.nextInt() - 1;
                        input.nextLine();

                        if (deleteIndex >= 0 && deleteIndex < busLinesToDelete.size()) {

                            // Remove the selected bus from the list
                            busLinesToDelete.remove(deleteIndex);
                            System.out.println("Bus deleted successfully.");

                            // Rewrite the updated list back into the file
                            try {
                                BufferedWriter writer = new BufferedWriter(new FileWriter(fileToDeleteFrom));
                                for (int i = 0; i < busLinesToDelete.size(); i++) {
                                    writer.write(busLinesToDelete.get(i));
                                    writer.newLine();
                                }
                                writer.close();
                            } catch (IOException e) {
                                System.out.println("Error writing to file: " + e.getMessage());
                            }

                        } else {
                            System.out.println("Invalid bus number.");
                        }

                        break;

                    case 4: // VIEW ALL
                        if (busServices.isEmpty()) {
                            System.out.println("No buses added yet.");
                        } else {
                            // Array of service names to organize the display
                            String[] services = {
                                    "Daewoo Express",
                                    "Faisal Movers",
                                    "Silk Line",
                                    "Al Makkah Travels",
                                    "Kainat Travels"
                            };

                            // Loop through each service to display its buses
                            for (int s = 0; s < services.length; s++) {
                                String service = services[s];
                                System.out.println("\n\t\t--- " + service + " ---\n");
                                boolean found = false;
                                int count = 1;

                                for (int i = 0; i < busServices.size(); i++) {
                                    if (busServices.get(i).startsWith(service)) {
                                        found = true;

                                        // Display formatted bus details
                                        System.out.println(count + ". " + busServices.get(i) +
                                                " | Route: " + busRoutes.get(i) +
                                                " | Fare: " + busFares.get(i) +
                                                " | Business Fare: " + busBusinessFares.get(i));
                                        count++;
                                    }
                                }

                                if (!found) {
                                    System.out.println("No buses available.");
                                }
                            }
                        }
                        break;

                    case 0:
                        System.out.println("Returning to Admin Dashboard...");
                        break;

                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input type. Please enter numbers only.");
                input.nextLine(); // clear invalid input
                busChoice = -1; // force loop to repeat
            } catch (ArrayIndexOutOfBoundsException e) {
                System.out.println("Error: Invalid index selected.");
            } catch (NumberFormatException e) {
                System.out.println("Error: Invalid number format.");
            }
        } while (busChoice != 0);
    }
}