

/**
 * Bus Booking Management System
 * 
 * This project allows users to:
 * - Manage their profile (update phone, email, name, password)
 * - Search buses by source, destination and date
 * - Select seats using a text-based layout
 * - Calculate fare based on seat class and quantity
 * - View past booking history
 * 
 * It also supports basic payment options and loyalty point tracking.
 */

// ─────────────────────────────────────────────────────────────────────────────
// SECTION: Date and I/O utilities
// ─────────────────────────────────────────────────────────────────────────────

import java.time.LocalDate; // Represents dates without time
import java.time.format.DateTimeFormatter; // Standard formatter for parsing/formatting dates
import java.time.format.DateTimeFormatterBuilder; // Used to build custom date formatters
import java.time.format.ResolverStyle; // Enforces strict date validation rules (e.g., no 31st June)
import java.time.format.DateTimeParseException; // Exception thrown when parsing fails
import java.io.*;
import java.util.*;

/**
 * FinalProject_AreebaNewPart
 * ---------------------------
 * A text-based bus reservation and user management system.
 * Supports user authentication, file-based data persistence, and city/bus
 * management.
 */
public class FinalUserModule {

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Global Data Structures
    // ─────────────────────────────────────────────────────────────────────────────

    static Scanner input = new Scanner(System.in); // Scanner for user input

    ////// static String selectedBusClass = "";

    // User data (in-memory storage for file-backed users)
    static ArrayList<String> userId = new ArrayList<>();
    static ArrayList<String> userPassword = new ArrayList<>();
    static ArrayList<String> firstNames = new ArrayList<>();
    static ArrayList<String> lastNames = new ArrayList<>();
    static ArrayList<String> phoneNumbers = new ArrayList<>();
    static ArrayList<Integer> points = new ArrayList<>();

    // Bus data per travel company
    static List<String> busNumbers = new ArrayList<>();
    static List<String> numberPlates = new ArrayList<>();
    static List<String> startingPoints = new ArrayList<>();
    static List<String> destinationPoints = new ArrayList<>();
    static List<Integer> economyFares = new ArrayList<>();
    static List<Integer> businessFares = new ArrayList<>();
    static List<String> busServices = new ArrayList<>();

    public static void loadBusDataFromFiles() {
        String[] busFiles = {
                "Daewooexpress.txt",
                "Faisalmovers.txt",
                "Silkline.txt",
                "Kainattravels.txt",
                "Almakkahtravels.txt"
        };

        // Loop through each bus data file provided in the 'busFiles' array.
        for (int i = 0; i < busFiles.length; i++) {
            String fileName = busFiles[i];

            // Use a try-with-resources statement to ensure the BufferedReader is properly
            // closed
            try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
                String line; // Variable to hold each line read from the file.

                // Read the file line by line until the end of the file is reached (line is
                // null).
                while ((line = reader.readLine()) != null) {

                    // Split each line by a comma (",") to separate the different data fields.
                    // The expected format is: BusNumber,Plate,PickUp to
                    // Destination,Fare,BusinessFare,Service
                    String[] parts = line.split(",");

                    // Validate that the line has the expected number of parts (6 in this case).
                    if (parts.length == 6) {

                        String busNum = parts[0].trim(); // Bus identification number
                        String plate = parts[1].trim(); // license plate number
                        String route = parts[2].trim(); // Combined pick-up and destination (e.g., "CityA to CityB")
                        String economyFareStr = parts[3].trim(); // Economy class fare as a string
                        String businessFareStr = parts[4].trim(); // Business class fare as a string
                        String busService = parts[5].trim(); // Name of the bus service/company

                        // Split the 'route' string by " to " to separate the pick-up and destination
                        // points.
                        String[] routeParts = route.split(" to ");

                        // Ensure the route format is correct, expecting exactly two parts (pick-up and
                        // destination).
                        if (routeParts.length == 2) {

                            String pickUp = routeParts[0].trim(); // Extracted pick-up point
                            String destination = routeParts[1].trim(); // Extracted destination point

                            // Add the parsed data to their respective global lists.
                            // These lists store bus details in parallel, where the index corresponds to a
                            // specific bus route's information.
                            busNumbers.add(busNum);
                            numberPlates.add(plate);
                            startingPoints.add(pickUp);
                            destinationPoints.add(destination);

                            // Parse fare strings to integers before adding them to the lists.
                            economyFares.add(Integer.parseInt(economyFareStr));
                            businessFares.add(Integer.parseInt(businessFareStr));
                            busServices.add(busService);

                        } else {
                            // Log an error if the route format within the file is incorrect
                            System.out.println("Invalid route format in " + fileName + ": " + route);

                        }
                    } else {
                        // Log an error if a line does not have the expected number of parts
                        System.out.println("Skipping malformed line in " + fileName + ": " + line);
                    }
                }

            } catch (IOException e) {

                // Catch and report any IOException that occurs during file reading (e.g., file
                // not found, permission issues).
                System.out.println("Error reading file " + fileName + ": " + e.getMessage());
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: User File Operations
    // ─────────────────────────────────────────────────────────────────────────────

    // Loads existing users from 'users.txt'
    // Expected line format: email password firstName lastName phone points
    public static void readUsersFromFile() {

        // Attempt to open and read from the "users.txt" file.
        try (BufferedReader br = new BufferedReader(new FileReader("User.txt"))) {
            String line; // Holds each line read from the file.

            // Read each line until the end of the file.
            while ((line = br.readLine()) != null) {

                // Split the line by space (" ") to separate user data fields.
                String[] parts = line.split(" ");

                // If the line has exactly 6 parts, process it as valid user data.
                if (parts.length == 6) {

                    // Parse and store each piece of user data into their respective lists.
                    // Each part is trimmed to remove any leading whitespace.
                    userId.add(parts[0].trim());
                    userPassword.add(parts[1].trim());
                    firstNames.add(parts[2].trim());
                    lastNames.add(parts[3].trim());
                    phoneNumbers.add(parts[4].trim());

                    // Convert the loyalty points string to an integer.
                    points.add(Integer.parseInt(parts[5].trim()));
                }
            }

        } catch (IOException e) {

            // Handle and report any file reading errors (e.g., file not found).
            System.out.println("Error reading users from file: " + e.getMessage());
        }
    }

    // Overwrites 'users.txt' with the current in-memory user data.
    // This is used after updates like point increment or password change.
    public static void writeAllUsersToFile() {

        // The 'FileWriter("users.txt", false) overwrites an existing one
        try (PrintWriter pw = new PrintWriter(new FileWriter("User.txt", false))) {

            // Iterate through each user's data, which is stored across parallel lists.
            // The loop index 'i' correlates all data for a single user.
            for (int i = 0; i < userId.size(); i++) {

                // Write each user's complete data as a single line to the "users.txt" file.
                // Fields are separated by spaces, matching the format used during reading.
                pw.println(userId.get(i) + " " +
                        userPassword.get(i) + " " +
                        firstNames.get(i) + " " +
                        lastNames.get(i) + " " +
                        phoneNumbers.get(i) + " " +
                        points.get(i));
            }

        } catch (IOException e) {

            // Catch and report any IOException that occurs during the file writing process.
            // This prevents application crashes and informs about I/O issues (e.g., disk
            // full, permissions).
            System.out.println("Error writing users to file: " + e.getMessage());
        }
    }

    // Appends a new user to 'users.txt' file after successful sign-up.
    public static void writeAllUserToFile(String email, String pass, String f, String l, String p, int pts) {

        // Open the 'users.txt' file in append mode (true).
        // This ensures new user data is added to the end of the file
        // without deleting existing user records.
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("User.txt", true))) {

            // Write the new user's details to the file, separated by spaces.
            // The data is written in the order: email, password, first name, last name,
            // phone, points.
            bw.write(email + " " + pass + " " + f + " " + l + " " + p + " " + pts);

            // starts on a fresh line, maintaining file readability and parseability.
            bw.newLine();

        } catch (IOException e) {

            // Handle any errors that occur during the file writing process.
            System.out.println("Error writing user to file: " + e.getMessage());
        }
    }

    // Clears all existing bus data from memory and then reloads it by reading
    // information from a predefined set of bus service data files.

    public static void readAllBuses() {

        // Define the list of bus data filenames to be processed.
        String[] filenames = {
                "Daewooexpress.txt",
                "Faisalmovers.txt",
                "Silkline.txt",
                "Almakkahtravels.txt",
                "Kainattravels.txt"
        };

        // Clear all existing bus data lists. This ensures that when buses are reloaded,
        // old data is removed, preventing duplication or outdated information.
        busNumbers.clear();
        numberPlates.clear();
        startingPoints.clear();
        destinationPoints.clear();
        economyFares.clear();
        businessFares.clear();
        busServices.clear();

        // Iterate through each filename and call a helper method to load bus data from
        // it.
        for (String filename : filenames) {
            readBusesFromFile(filename);
        }
    }

    /**
     * Reads a single bus data file and parses its records into the application's
     * in-memory lists. Each line in the file is expected to contain comma-separated
     * bus details including number, plate, route (e.g., "CityA to CityB"), fares,
     * and service name.
     * Lines not matching the expected format are skipped with a warning.
     *
     * @param filename The path to the bus data file to be read.
     */
    public static void readBusesFromFile(String filename) {

        // Open the specified file for reading using a BufferedReader for efficiency.
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {

            String line; // Variable to hold each line read from the file.

            // Read the file line by line until no more lines are available.
            while ((line = br.readLine()) != null) {

                // Split the line into parts using a comma as the delimiter.
                String[] parts = line.split(",");

                // Validate that the line contains exactly 6 expected fields.
                if (parts.length == 6) {

                    // Extract and trim each data part. Fares are parsed to integers.
                    String busNumber = parts[0].trim();
                    String numberPlate = parts[1].trim();
                    String route = parts[2].trim();

                    int economyFare = Integer.parseInt(parts[3].trim());
                    int businessFare = Integer.parseInt(parts[4].trim());
                    String service = parts[5].trim();

                    // Locate the " to " separator in the route string to split it into
                    // distinct starting and destination points.
                    int toIndex = route.toLowerCase().indexOf(" to ");
                    if (toIndex != -1) {

                        // Extract and trim the start and end points from the route string.
                        String start = route.substring(0, toIndex).trim();
                        String end = route.substring(toIndex + 4).trim(); // +4 to skip " to "

                        // Add the parsed bus details to their respective global data lists.
                        busNumbers.add(busNumber);
                        numberPlates.add(numberPlate);
                        startingPoints.add(start);
                        destinationPoints.add(end);
                        economyFares.add(economyFare);
                        businessFares.add(businessFare);
                        busServices.add(service);
                    }

                    // If 'toIndex' is -1, the route format is invalid; this specific record is
                    // skipped.
                } else {

                    // Output a warning for lines that don't match the expected field count,
                    // indicating potential data formatting issues in the file.
                    System.out.println("Skipped invalid line in " + filename + ": " + line);
                }
            }
        } catch (IOException e) {

            // Log an error if any I/O problem occurs during file reading (e.g., file not
            // found).
            System.out.println("Error reading buses from file " + filename + ": " + e.getMessage());
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Application Entry Point
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Main method: Program entry point. Loads data and prompts login/signup.
     */
    public static void run() {
        System.out.println("\u001b[31m");
System.out.println("\r\n" + //
"██╗   ██╗███████╗███████╗██████╗     ██████╗  █████╗ ███████╗██╗  ██╗██████╗  ██████╗  █████╗ ██████╗ ██████╗ \r\n" + //
"██║   ██║██╔════╝██╔════╝██╔══██╗    ██╔══██╗██╔══██╗██╔════╝██║  ██║██╔══██╗██╔═══██╗██╔══██╗██╔══██╗██╔══██╗\r\n" + //
"██║   ██║███████╗█████╗  ██████╔╝    ██║  ██║███████║███████╗███████║██████╔╝██║   ██║███████║██████╔╝██║  ██║\r\n" + //
"██║   ██║╚════██║██╔══╝  ██╔══██╗    ██║  ██║██╔══██║╚════██║██╔══██║██╔══██╗██║   ██║██╔══██║██╔══██╗██║  ██║\r\n" + //
"╚██████╔╝███████║███████╗██║  ██║    ██████╔╝██║  ██║███████║██║  ██║██████╔╝╚██████╔╝██║  ██║██║  ██║██████╔╝\r\n" + //
" ╚═════╝ ╚══════╝╚══════╝╚═╝  ╚═╝    ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ \r\n" + //
"                                                                                                              \r\n" + //
"");

System.out.println("\u001b[0m");

        // Load user data from file before login/sign-up
        readUsersFromFile(); // Load user accounts

        int choice = -1;

        // Prompt for login or sign-up choice
        do {

            try {
                System.out.println("\n==============================");
            System.out.println("|       MAIN MENU            |");
            System.out.println("==============================");
            System.out.println("| 1. Sign In                 |");
            System.out.println("| 2. Sign Up                 |");
            System.out.println("| 0. Exit                    |");
            System.out.println("==============================");
            System.out.print("Enter your choice: ");
                choice = input.nextInt();
                input.nextLine(); // Clear buffer

                if (choice != 0 && choice != 1 && choice != 2)
                    System.out.println("Invalid choice. Please enter 0 or 1.");

            } catch (InputMismatchException ex) {
                System.out.println(" Invalid input. Please enter a numeric value (0 or 1).");
                input.nextLine(); // Clear input
            }

        } while (choice != 0 && choice != 1 && choice != 2); // Loop until valid input

        // Proceed to appropriate section
        if (choice == 1)
            logIn(); // Login existing user
        else if (choice==2)
            signUp();
        else
            return; // Register a new user
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: User Authentication
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Handles the user login process.
     * It prompts the user for their email ID and validates it against registered
     * users.
     * Once the email is found, it prompts for a password and allows up to 3
     * attempts.
     * Upon successful login, it directs the user to the main user menu.
     * If login fails after multiple attempts, it indicates an account lock.
     */
    public static void logIn() {
        boolean emailFound = false; // Flag to indicate if the entered email exists
        int emailIndex = -1; // Stores the index of the found email in the user lists
        String emailId; // Variable to hold user-entered email ID

        // Step 1: Get and validate email ID. This loop continues until a registered
        // email is found.
        do {
            System.out.print("Enter your Email ID: ");
            emailId = input.next(); // Reads only the next token (word)

            // Iterate through the stored user IDs to find a match for the entered email.
            for (int i = 0; i < userId.size(); i++) {

                if (userId.get(i).equals(emailId)) {
                    emailFound = true; // Set flag to true if email is found
                    emailIndex = i; // Store the index of the matched email
                    break; // Exit the loop early once a match is found
                }
            }

            // Provide feedback if the email was not found.
            if (!emailFound) {
                System.out.println("Email not found. Try again.");
            }

        } while (!emailFound); // Repeat until a valid email is entered

        input.nextLine(); // Consumes the remaining newline character from the buffer

        // Step 2: Validate password with a maximum of 3 attempts.
        int attempts = 0; // Counter for login attempts
        boolean passwordCorrect = false; // Flag for successful password validation

        // Loop until the password is correct or maximum attempts are exhausted.
        while (!passwordCorrect && attempts < 3) {
            System.out.print("Enter your password: ");
            String password = input.nextLine(); // Reads the entire line for password

            // Check if the entered password matches the stored password for the found
            // email.
            if (password.equals(userPassword.get(emailIndex))) {

                System.out.println("\nYou have successfully logged in!");
                userMenu(emailIndex); // Direct user to the main menu
                passwordCorrect = true; // Set flag to true to exit the loop

            } else {
                attempts++; // Increment attempt counter on incorrect password

                // Provide feedback on remaining attempts or account lock status.
                if (attempts < 3) {
                    System.out.println("Wrong password. Attempts left: " + (3 - attempts));

                } else {
                    System.out.println("Too many failed attempts. Your account is temporarily locked.");
                }
            }
        }
    }

    /**
     * Signs up a new user with validation for name, email, password, and phone.
     */
    public static void signUp() {
        try {
            System.out.println("\n🔐 Sign-Up Form");

            // Step 1: Get user's first and last name
            System.out.print("Enter your First Name: ");
            String firstName = input.next();

            System.out.print("Enter your Last Name: ");
            String lastName = input.next();

            // Step 2: Get and validate email
            String emailId;

            do {
                System.out.print("Enter your Email ID: ");
                emailId = input.next();

                if (!emailValidation(emailId)) {
                    System.out.println("❌ Invalid email. Try something like user@gmail.com");

                } else if (userId.contains(emailId)) {
                    System.out.println("⚠ This email is already registered. Try logging in.");
                    return; // Stop sign-up
                }

            } while (!emailValidation(emailId));

            input.nextLine(); // Clear buffer

            // Step 3: Get and validate password
            String password;
            do {
                System.out.print("Enter your password: ");
                password = input.nextLine();

                if (password.contains(" ")) {
                    System.out.println("❌ Password cannot contain space.");

                } else if (!isValidPassword(password)) {
                    System.out.println("⚠ Try again with a stronger password.");

                } else {
                    System.out.println("✅ Strong password accepted!");
                    break;
                }

            } while (true);

            // Step 4: Get and validate phone number
            String phone;
            boolean phoneExists;

            do {
                System.out.print("Enter your Phone Number (format: +923XXXXXXXXX): ");
                phone = input.nextLine();
                phoneExists = phoneNumbers.contains(phone);

                if (!isValidPhone(phone)) {
                    System.out.println("❌ Invalid phone number format.");

                } else if (phoneExists) {
                    System.out.println("⚠ This phone number is already registered.");

                } else {
                    break; // Valid phone number
                }

            } while (true);

            // Step 5: Store all details in ArrayLists
            userId.add(emailId);
            userPassword.add(password);
            firstNames.add(firstName);
            lastNames.add(lastName);
            phoneNumbers.add(phone);
            points.add(0);

            // Step 6: Write to file for future sessions
            writeAllUserToFile(emailId, password, firstName, lastName, phone, 0);

            System.out.println("🎉 Account created successfully!");
            userMenu(userId.size() - 1); // Pass the current user index

        } catch (Exception e) {
            System.out.println("❌ Error during sign-up: " + e.getMessage());
        }
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Validation Helpers
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * validates email domain
     * 
     * @param emailId The email address string to be validated.
     * @return True if the email matches the validation criteria, false otherwise.
     */
    public static boolean emailValidation(String emailId) {

        // Checks if the email contains an '@' symbol and ends with one of the specified
        // domains.
        return emailId.contains("@") && (emailId.endsWith("@gmail.com") ||
                emailId.endsWith("@outlook.com") ||
                emailId.endsWith("@yahoo.com") ||
                emailId.endsWith("@icloud.com") ||
                emailId.endsWith("@aol.com") ||
                emailId.endsWith("@zoho.com") ||
                emailId.endsWith("@gmx.com"));
    }

    // ---------------------------------------
    // Validates password strength by checking for:
    // uppercase, lowercase, digit, special character, length (≥9), and no spaces
    public static boolean isValidPassword(String password) {
        boolean hasUpper = false, hasLower = false, hasDigit = false, hasSpecial = false;

        // Password must be at least 9 characters long
        if (password.length() < 9) {
            System.out.println("Password must be at least 9 characters long.");
            return false;
        }

        // Check for space characters (not allowed)
        if (password.contains(" ")) {
            System.out.println("Password cannot contain spaces.");
            return false;
        }

        // Loop through each character to check character types
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasUpper = true;

            } else if (Character.isLowerCase(ch)) {
                hasLower = true;

            } else if (Character.isDigit(ch)) {
                hasDigit = true;

            } else {
                hasSpecial = true; // Consider all other characters as special
            }
        }

        // Print hints for missing types
        if (!hasUpper)
            System.out.println("Missing uppercase letter.");

        if (!hasLower)
            System.out.println("Missing lowercase letter.");

        if (!hasDigit)
            System.out.println("Missing digit.");

        if (!hasSpecial)
            System.out.println("Missing special character.");

        return hasUpper && hasLower && hasDigit && hasSpecial;
    }

    // ---------------------------------------
    // Validates phone number
    public static boolean isValidPhone(String phone) {
        // Check length: should be exactly 13 characters (e.g., "+923XXXXXXXXX")
        if (phone.length() != 13) {
            return false;
        }

        // Check prefix: must start with "+92"
        if (!phone.startsWith("+92")) {
            return false;
        }

        // The 4th character (index 3) must be '3' (for mobile numbers starting with
        // +923)
        if (phone.charAt(3) != '3') {
            return false;
        }

        // Check remaining characters are all digits
        for (int i = 4; i < 13; i++) {
            char ch = phone.charAt(i);

            if (ch < '0' || ch > '9') {
                return false; // Found a non-digit character
            }
        }

        // All checks passed, phone is valid
        return true;
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: User Menu
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Displays the main dashboard menu for a logged-in user and handles their
     * selections.
     * The menu provides options to view/update profile, search/book buses, view
     * loyalty points,
     * and check booking history. The loop continues until the user explicitly
     * chooses to log out.
     *
     * @param emailIndex The index of the currently logged-in user in the global
     *                   user data lists.
     */
    public static void userMenu(int emailIndex) {
        int choice; // Variable to store the user's menu choice

        do {
            // Display the user dashboard menu options to the console.
            System.out.println("\n--- User Dashboard ---");
            System.out.println("1. View Profile");
            System.out.println("2. Update Profile");
            System.out.println("3. Search & Book Bus");
            System.out.println("4. View Points");
            System.out.println("5. Booking History");
            System.out.println("0. Logout");
            System.out.print("Enter your choice: ");

            try {

                // Read the user's input and attempt to parse it as an integer.
                choice = Integer.parseInt(input.nextLine());

                // Use a switch statement to perform actions based on the user's choice.
                switch (choice) {

                    case 1:
                        // Calls the method to display the user's profile details.
                        viewProfile(emailIndex);
                        break;

                    case 2:
                        // Calls the method to allow the user to update their profile information.
                        updateProfile(emailIndex);
                        break;

                    case 3:
                        // Initiates the bus search and booking process.
                        searchBusRoutes(emailIndex);
                        break;

                    case 4:
                        // Displays the current loyalty points for the logged-in user.
                        System.out.println("Your points: " + points.get(emailIndex));
                        break;

                    case 5:
                        // Retrieves the user's phone number and displays their booking history.
                        String userPhone = phoneNumbers.get(emailIndex);
                        showBookingHistory(userPhone);
                        break;

                    case 0:
                        // Informs the user that they are logging out.
                        System.out.println("Logging out...");
                        break;

                    default:
                        // Handles cases where the input number is not a valid menu option.
                        System.out.println("Invalid choice.");
                        break;
                }

            } catch (NumberFormatException e) {

                // Catches an exception if the user's input cannot be converted to a number.
                System.out.println("Enter a number.");
                choice = -1; // Reset choice to a non-zero value to keep the loop running
            }

        } while (choice != 0); // Continue displaying the menu until the user chooses to logout (0).
    }

    // ---------------------------------------
    // Displays the logged-in user's profile information
    // Accepts emailIndex to fetch user-specific details
    public static void viewProfile(int emailIndex) {
        System.out.println("\n\t\t --- Your Profile ---");

        // Display user details from corresponding lists
        System.out.println("First Name   : " + firstNames.get(emailIndex));
        System.out.println("Last Name    : " + lastNames.get(emailIndex));
        System.out.println("Email ID     : " + userId.get(emailIndex));
        System.out.println("Phone Number : " + phoneNumbers.get(emailIndex));
        System.out.println("Points       : " + points.get(emailIndex));

        // Note: Password is intentionally not displayed for security
    }

    // ---------------------------------------
    // Allows the user to update their profile fields
    // including phone, email, names, and password
    public static void updateProfile(int emailIndex) {
        int updateChoice = -1; // stores user's menu selection

        do {
            // Display the update menu
            System.out.println("\n--- Update Menu ---");
            System.out.println("1. Add/Update Phone Number");
            System.out.println("2. Update Email");
            System.out.println("3. Update First Name");
            System.out.println("4. Update Last Name");
            System.out.println("5. Update Password");
            System.out.println("0. Exit");

            System.out.print("Enter your choice: ");

            try {
                // Take input and parse it to an integer
                updateChoice = Integer.parseInt(input.nextLine());

                switch (updateChoice) {

                    // --------------------------
                    // Case 1: Update Phone Number
                    case 1:
                        String phone;
                        boolean phoneExists;

                        do {
                            System.out.print("Enter your new Phone Number (format: +923XXXXXXXXX): ");
                            phone = input.nextLine().trim();

                            // Check if phone is already used by another user
                            phoneExists = phoneNumbers.contains(phone) &&
                                    !phone.equals(phoneNumbers.get(emailIndex));

                            // Validate format and uniqueness
                            if (!isValidPhone(phone)) {
                                System.out.println("Invalid phone number.");

                            } else if (phoneExists) {
                                System.out.println("This phone number is already registered.");
                            }

                        } while (!isValidPhone(phone) || phoneExists);

                        // Update phone number in the list
                        phoneNumbers.set(emailIndex, phone);
                        System.out.println("Phone number updated.");
                        break;

                    // --------------------------
                    // Case 2: Update Email
                    case 2:
                        String newEmail;
                        boolean emailExists;

                        do {
                            System.out.print("Enter new Email ID: ");
                            newEmail = input.nextLine().trim();

                            // Check if email is used by another user
                            emailExists = userId.contains(newEmail) &&
                                    !newEmail.equals(userId.get(emailIndex));

                            // Validate email format and uniqueness
                            if (!emailValidation(newEmail)) {
                                System.out.println("Invalid Email.");

                            } else if (emailExists) {
                                System.out.println("This email is already in use.");
                            }

                        } while (!emailValidation(newEmail) || emailExists);

                        // Update email
                        userId.set(emailIndex, newEmail);
                        System.out.println("Email updated.");
                        break;

                    // --------------------------
                    // Case 3: Update First Name
                    case 3:
                        System.out.print("Enter new First Name: ");
                        String newFirst = input.nextLine().trim();

                        firstNames.set(emailIndex, newFirst);
                        System.out.println("First name updated.");
                        break;

                    // --------------------------
                    // Case 4: Update Last Name
                    case 4:
                        System.out.print("Enter new Last Name: ");
                        String newLast = input.nextLine().trim();
                        lastNames.set(emailIndex, newLast);
                        System.out.println("Last name updated.");
                        break;

                    // --------------------------
                    // Case 5: Update Password
                    case 5:
                        System.out.print("Enter your current password: ");
                        String oldPassword = input.nextLine();

                        // Check if old password is correct
                        if (!oldPassword.equals(userPassword.get(emailIndex))) {
                            System.out.println("Incorrect current password. Password not updated.");
                            break;
                        }

                        String newPassword;

                        do {
                            System.out.print("Enter new password (no spaces allowed): ");
                            newPassword = input.nextLine();

                            // Validate new password format
                            if (newPassword.contains(" ")) {
                                System.out.println("Password cannot contain spaces.");

                            } else if (isValidPassword(newPassword)) {
                                System.out.println("Strong password!");
                                break; // valid password

                            } else {
                                System.out.println(
                                        "Password must contain uppercase, lowercase, digit, and special character.");
                            }

                        } while (true);

                        // Update password
                        userPassword.set(emailIndex, newPassword);
                        System.out.println("Password updated.");
                        break;

                    // --------------------------
                    // Case 0: Exit update menu
                    case 0:
                        System.out.println("Exiting profile update.");
                        break;

                    // --------------------------
                    // Invalid menu choice
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }

            } catch (NumberFormatException ex) {

                // If input is not a valid integer
                System.out.println("Please enter a valid number.");
            }

        } while (updateChoice != 0); // repeat until user chooses to exit

        // Save updated data to file after all changes
        writeAllUsersToFile();

        System.out.println("Your updated profile:");
        viewProfile(emailIndex);

    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Travel Date Validation
    // ─────────────────────────────────────────────────────────────────────────────

    // ---------------------------------------
    // Method to get a valid travel date within the next 14 days
    public static LocalDate getValidTravelDate() {

        // Strict formatter: will reject invalid calendar dates like 31-06-2025 or
        // 30-02-2025
        DateTimeFormatter formatter = new DateTimeFormatterBuilder()
                .appendPattern("dd-MM-uuuu")
                .toFormatter()
                .withResolverStyle(ResolverStyle.STRICT); // Enforces strict date validation

        // Get today's date
        LocalDate today = LocalDate.now();

        // Calculate the maximum allowable travel date (14 days from today)
        LocalDate maxDate = today.plusDays(14);

        // Inform the user of the valid booking date range
        System.out.println("You can book between " + today.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")) +
                " and " + maxDate.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));

        // Prompt user for travel date input
        System.out.print("Enter travel date (dd-MM-yyyy): ");
        String dateInput = input.nextLine(); // Read date as string

        try {
            // Parse the input string into a LocalDate using the defined formatter
            LocalDate userDate = LocalDate.parse(dateInput, formatter);

            // Check if the input date is outside the allowed 14-day window
            if (userDate.isBefore(today) || userDate.isAfter(maxDate)) {
                System.out.println("Date must be within 14 days from today.");
                return null; // Invalid: not in range
            }

            // Valid date in range
            return userDate;

        } catch (DateTimeParseException e) {
            // Handle invalid format or impossible calendar dates
            System.out.println("Invalid date. Please use dd-MM-yyyy and make sure it exists in calendar.");
            return null;
        }
    }

    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Searching and Validation of Bus Routes
    // ─────────────────────────────────────────────────────────────────────────────

    /// ---------------------------------------
    // Search for valid bus routes
    /**
     * Initiates the bus route search and booking process for a logged-in user.
     * This method first ensures that all bus data is loaded into memory,
     * and then proceeds to guide the user through selecting a travel route.
     *
     * @param emailIndex The index of the currently logged-in user, used to
     *                   personalize
     *                   the booking process and associate bookings.
     */
    public static void searchBusRoutes(int emailIndex) {

        readAllBuses(); // Call method to load (or reload) all bus data from respective files into
                        // memory.
        validateAndSelectBusRoute(emailIndex); // Redirects to the core logic for route selection and validation.
    }

    // ---------------------------------------
    // Validates user’s route input and matches available buses
    /**
     * Guides the user through selecting a bus route by prompting for travel date,
     * pick-up point, and destination. It validates each input against available
     * data
     * and proceeds to display and offer booking for suitable, available buses.
     * If no buses match the criteria or all matching buses are fully booked,
     * appropriate messages are displayed.
     *
     * @param emailIndex The index of the currently logged-in user in the global
     *                   user lists.
     *                   This index is crucial for associating any successful
     *                   bookings with the user.
     */
    public static void validateAndSelectBusRoute(int emailIndex) {

        String pickUp, destination; // Variables to store the user's chosen pick-up and destination points.

        // Step 1: Get and validate the desired travel date from the user.
        LocalDate travelDate = getValidTravelDate();
        if (travelDate == null) {
            // If getValidTravelDate() returns null, it means the user entered an invalid
            // date
            // and the method has already printed an error message. Exit this method.
            return;
        }

        // Step 2: Get and validate the pick-up point from the user.
        // This loop ensures the user provides a non-empty, recognized pick-up location.
        while (true) {

            System.out.print("Enter your pick-up point: ");
            pickUp = input.nextLine().trim(); // Read user input and remove leading/trailing whitespace.

            if (pickUp.isEmpty()) {

                // Error if input is blank.
                System.out.println("Input cannot be empty.");
                continue; // Ask for input again.
            }

            boolean found = false; // Flag to check if the entered pick-up point exists in our data.

            // Iterate through all known starting points to find a case-insensitive match.
            for (String s : startingPoints) {

                if (s.equalsIgnoreCase(pickUp)) {
                    // If a match is found, store the actual stored) version of the point.
                    pickUp = s;
                    found = true;
                    break; // Exit the loop early as the point is found.
                }
            }
            if (found) {
                break; // Exit the 'while(true)' loop if a valid pick-up point was found.
            }
            System.out.println("Pick-up point not found."); // Error if no match was found.
        }

        // Step 3: Get and validate the destination point from the user.
        // This loop ensures the user provides a non-empty, recognized destination,
        // and that it's different from the pick-up point.
        while (true) {
            System.out.print("Enter your destination point: ");
            destination = input.nextLine().trim(); // Read user input and remove leading/trailing whitespace.

            // Validate that destination is not empty and not the same as the pick-up point.
            if (destination.isEmpty() || destination.equalsIgnoreCase(pickUp)) {

                System.out.println("Invalid destination. Destination cannot be empty or same as pick-up.");
                continue; // Ask for input again.
            }

            boolean found = false; // Flag to check if the entered destination point exists.

            // Iterate through all known destination points to find a case-insensitive
            // match.
            for (String d : destinationPoints) {

                if (d.equalsIgnoreCase(destination)) {
                    // If a match is found, store the canonical version of the point.
                    destination = d;
                    found = true;
                    break; // Exit the loop early.
                }
            }

            if (found) {
                break; // Exit the 'while(true)' loop if a valid destination was found.
            }

            System.out.println("Destination not found."); // Error if no match.
        }

        // Step 4: Find all buses that match the user's specified pick-up and
        // destination route.
        List<Integer> matchingBusIndices = new ArrayList<>(); // A list to store the indices of matching buses.

        // Iterate through all loaded bus data.
        for (int i = 0; i < busNumbers.size(); i++) {

            // Check if the starting point AND destination point of the current bus (at
            // index 'i')
            // match the user's input, ignoring case.
            if (startingPoints.get(i).equalsIgnoreCase(pickUp) &&
                    destinationPoints.get(i).equalsIgnoreCase(destination)) {

                matchingBusIndices.add(i); // If both match, add this bus's index to our list.
            }
        }

        // If no buses were found for the specified route, inform the user and exit.
        if (matchingBusIndices.isEmpty()) {
            System.out.println("No buses available for this route.");
            return;
        }

        // Step 5: Iterate through the found matching buses, check their seat
        // availability,
        // and offer the first available one for booking.
        for (int index : matchingBusIndices) {

            String busNum = busNumbers.get(index); // Get the bus number for the current matching bus.
            String numberPlate = numberPlates.get(index); // Get the number plate.

            // Check if the current bus has available seats (40 is max capacity).
            // getBookedSeatsCount(busNum) would return how many seats are currently booked
            // for this bus.
            if (getBookedSeatsCount(busNum) < 40) {

                System.out.println("\nBus Available!");

                // Display details of the available bus.
                System.out.println("Service: " + busServices.get(index));
                System.out.println("Bus #: " + busNum + " | Plate: " + numberPlate);
                System.out.println(
                        "Fare: Rs " + economyFares.get(index) + " | Business: Rs " + businessFares.get(index));

                // Proceed to the booking interface for this specific available bus.
                // Passes necessary details to the bookSeats method.
                bookSeats(numberPlate, pickUp, destination, emailIndex, travelDate);
                return; // After booking one bus (or attempting to), exit the method.
            }
        }

        // If the loop finishes, it means all matching buses were fully booked.
        System.out.println("All buses on this route are fully booked.");
    }


    // ---------------------------------------
    /**
     * Counts the total number of booked seats for a specific bus from its dedicated seat file.
     * Each line in the bus's seat file is assumed to represent one booked seat.
     *
     * @param busPlate The license plate of the bus (e.g., "ABC-123"), which is used to construct the filename (e.g., "ABC-123.txt").
     * @return The total count of lines (i.e., booked seats) found in the file. Returns 0 if the file does not exist or if an error occurs.
     */
    public static int getBookedSeatsCount(String busPlate) {

        // Construct a File object representing the bus's specific seat booking file.
        // The filename is derived directly from the busPlate followed by ".txt".
        File file = new File(busPlate + ".txt");

        // Check if the seat booking file for this bus actually exists.
        // If it doesn't exist, it means no seats have been booked yet for this bus,
        // so the count is effectively 0.
        if (!file.exists())
            return 0;

        // Initialize a counter for the number of lines (booked seats).
        int count = 0;

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            // Read lines from the file one by one until the end of the file is reached (readLine() returns null).
            while (br.readLine() != null) {

                count++; // Increment the counter for each line read, as each line represents one booked seat.
            }
        } catch (IOException e) {
            System.out.println("Error counting booked seats.");
        }

        // Return the final count of booked seats.
        return count;
    }


    // ---------------------------------------
    /**
     * Loads and returns a list of integer seat numbers that are currently booked for a specific bus.
     * This method reads the bus's dedicated seat file, extracts the seat number from each line,
     * and compiles them into a list.
     *
     * @param busPlate The license plate of the bus, used to identify its booking file.
     * @return A List of Integers representing the numbers of all currently booked seats.
     * Returns an empty list if the file does not exist or if no valid seat numbers are found.
     */
    public static List<Integer> loadBookedSeats(String busPlate) {

        // Initialize an empty ArrayList to store the booked seat numbers.
        List<Integer> booked = new ArrayList<>();

        // Construct a File object for the bus's seat booking file.
        File file = new File(busPlate + ".txt");

        // Check if the file exists. If not, no seats are booked, so return the empty list.
        if (!file.exists())
            return booked;

        // Use a try-with-resources statement for safe and automatic closing of the BufferedReader and FileReader.
        try (BufferedReader br = new BufferedReader(new FileReader(file))) {

            String line;
            // Read each line from the file until the end is reached.
            while ((line = br.readLine()) != null) {

                // Each line is expected to be in a format like "SeatNumber,Gender,Class" (e.g., "10,Male,Economy").
                String[] parts = line.split(",");

                // Ensure that the line has at least one part (i.e., it's not an empty or malformed line).
                if (parts.length >= 1) {
                    try {

                        // Attempt to parse the first part of the line (index 0) as an integer.
                        // .trim() is used to remove any leading/trailing whitespace around the number.
                        booked.add(Integer.parseInt(parts[0].trim()));

                    } catch (NumberFormatException ignored) {
                        // Catch NumberFormatException if the first part of the line cannot be parsed as an integer.
                        // The 'ignored' variable indicates that we simply skip this line if it's malformed,
                        // rather than crashing the program or printing an error message for every bad line.
                        // This allows the program to continue loading other valid bookings.
                    }
                }
            }

        } catch (IOException e) {
            // Catch any IOException that might occur during file reading.
            // Prints a general failure message to the console.
            System.out.println("Failed to load bookings.");
        }

        // Return the list containing all successfully loaded booked seat numbers.
        return booked;
    }


    /**
     * Initializes the seat booking file for a bus if it does not already exist.
     * This method simulates initial random bookings for a bus when it's encountered for the first time.
     * If the bus's file already exists, it skips initialization, assuming it's already set up.
     *
     * @param busPlate The license plate of the bus (e.g., "ABC-123"), used to create the corresponding filename (e.g., "ABC-123.txt").
     */
    public static void initializeBusSeatsIfFirstTime(String busPlate) {

        // Construct a File object representing the bus's specific seat booking file.
        // The filename is derived directly from the busPlate followed by ".txt".
        File file = new File(busPlate + ".txt");

        // --- Check for existing initialization ---
        // If the bus's seat booking file already exists, it means the bus has been initialized before.
        // In this case, there's no need to generate random initial bookings, so the method returns immediately.
        if (file.exists())
            return; // Skip initialization if file already present.

        // --- Simulate Initial Random Bookings ---
        // Initialize a Random object for generating various random numbers (seat count, seat number, gender).
        Random random = new Random();
        // Create an ArrayList to temporarily store the randomly selected seat numbers that will be "booked".
        List<Integer> seatsToBook = new ArrayList<>();

        // Determine a random number of seats to initially "book" for this bus.
        // 'random.nextInt(40)' generates a number from 0 to 39. Adding 1 makes the range 1 to 40.
        int totalRandomSeats = 1 + random.nextInt(40); // Generates a random count between 1 and 40 (inclusive).

        // Loop to select unique random seat numbers until the 'totalRandomSeats' count is reached.
        while (seatsToBook.size() < totalRandomSeats) {
            // Generate a random seat number between 1 and 40 (inclusive).
            int randomSeat = 1 + random.nextInt(40); // Seat number 1–40

            // Check if the randomly generated seat number is NOT already in our list of seats to book.
            // This ensures that each seat in 'seatsToBook' is unique.
            if (!seatsToBook.contains(randomSeat)) {
                seatsToBook.add(randomSeat); // Add the unique random seat number to the list.
            }
        }

        // --- Write Initial Bookings to File ---
        // PrintWriter is used for convenient text writing (including println for new lines).
        // FileWriter opens the file for writing (and creates it if it doesn't exist).
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {

            // Iterate through each randomly selected seat number.
            for (int seat : seatsToBook) {

                // Randomly assign a gender ("Male" or "Female") for the occupant of this seat.
                // random.nextBoolean() returns true or false.
                String gender = random.nextBoolean() ? "Male" : "Female";

                // Determine the class of the seat based on its number:
                // Seats 1-15 are considered Business class, and 16-40 are Economy.
                String seatClass = (seat <= 15) ? "Business" : "Economy";

                // Write the booking details for the seat to the file,
                // formatted as "SeatNumber,Gender,Class" followed by a new line.
                pw.println(seat + "," + gender + "," + seatClass);
            }

        } catch (IOException e) {
            // Catch any IOException that might occur during file writing (e.g., permission issues, disk full).
            // Prints a generic error message to the console if the file creation/writing fails.
            System.out.println("Failed to initialize seat file.");
        }
    }


    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Book Seats
    // ─────────────────────────────────────────────────────────────────────────────

    // ---------------------------------------
    // Books available seats based on user class and gender
    /**
     * Handles the seat booking process for a selected bus route.
     * This method manages seat availability, allows the user to choose seat class
     * and gender,
     * calculates the total fare, processes payment, generates a booking ID and
     * time,
     * saves booking records, and finally prints a ticket.
     * It also includes logic for re-routing to another bus if the initial bus is
     * fully booked.
     *
     * @param busPlate    The license plate of the selected bus, used to identify
     *                    it.
     * @param pickUp      The chosen pick-up location for the journey.
     * @param destination The chosen destination for the journey.
     * @param emailIndex  The index of the logged-in user in the global user data
     *                    lists.
     * @param travelDate  The date selected by the user for travel.
     */
    public static void bookSeats(String busPlate, String pickUp, String destination, int emailIndex,
            LocalDate travelDate) {

        final int TOTAL_SEATS = 40; // Maximum capacity of the bus.
        final int BUSINESS_SEATS = 15; // Number of seats designated as Business Class.

        // Ensure the bus's seat booking file exists and is initialized if it's the
        // first time accessing it.
        initializeBusSeatsIfFirstTime(busPlate);

        // Load the currently booked seats for this specific bus from its file.
        List<Integer> bookedSeats = loadBookedSeats(busPlate);

        // Find the index of the current bus in the main bus data lists
        int busIndex = numberPlates.indexOf(busPlate);

        if (busIndex == -1) {
            System.out.println("Error: Bus not found in list."); // Should not happen if previous logic is sound.
            return; // Exit if bus somehow isn't found.
        }

        // Check if the current bus is already fully booked.
        if (bookedSeats.size() >= TOTAL_SEATS) {
            System.out.println("This bus is fully booked. Searching for another bus...");
            

            // If current bus is full, try to find another available bus on the same route.
            for (int i = 0; i < startingPoints.size(); i++) {

                // Check if another bus operates on the same pick-up and destination route.
                if (startingPoints.get(i).equalsIgnoreCase(pickUp) &&
                        destinationPoints.get(i).equalsIgnoreCase(destination)) {
                    String otherBus = numberPlates.get(i);

                    // Skip the current bus if it's the one we just determined is full.
                    if (otherBus.equals(busPlate))
                        continue;

                    // Initialize seats for the alternative bus if needed and load its bookings.
                    initializeBusSeatsIfFirstTime(otherBus);
                    List<Integer> otherBookings = loadBookedSeats(otherBus);

                    // If the alternative bus has available seats, recursively call bookSeats for
                    // it.
                    if (otherBookings.size() < TOTAL_SEATS) {

                        System.out.println("Found an alternative bus: " + otherBus);
                        bookSeats(otherBus, pickUp, destination, emailIndex, travelDate); // Recursive call
                        return; // Exit after attempting to book on the alternative bus.
                    }
                }
            }

            // If no other available buses are found for the route.
            System.out.println("No available buses found on this route.");
            return; // Exit the method.
        }

        // --- Proceed with booking seats on the current bus if it has capacity ---

        // Ask how many seats to book
        System.out.print("How many seats would you like to book? ");
        int totalToBook;
        try {
            totalToBook = Integer.parseInt(input.nextLine().trim());
            // Calculate available seats BEFORE the 'if' condition
            int availableSeats = TOTAL_SEATS - bookedSeats.size();

            // Check if the input is less than 1 OR more than the actually available seats
            if (totalToBook < 1 || totalToBook > availableSeats) {
                // Change the error message here
                System.out.println("Invalid number of seats. Maximum seats available for booking: " + availableSeats);
                return; // Exit if invalid.
            }
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a number.");
            return;
        }

        // Initialize lists and counters for the new booking session.
        List<String> newBookings = new ArrayList<>(); // Stores details of seats booked in this session (e.g.,
                                                      // "10,Male,Economy").
        int bookedCount = 0; // Counts seats successfully booked in current session.
        int businessCount = 0; // Counts business class seats booked.
        int economyCount = 0; // Counts economy class seats booked.
        int totalFare = 0; // Accumulates total fare for all seats.

        // Temporary variables to hold data that will be used for printing the final
        // ticket.
        String tempUserEmail = userId.get(emailIndex);
        String tempBusNum = busNumbers.get(busIndex);
        String tempBusService = busServices.get(busIndex);

        String tempRoute = startingPoints.get(busIndex) + " to " + destinationPoints.get(busIndex);

        String tempTime = ""; // Will be generated randomly later.
        String tempSelectedClass = ""; // Will be determined based on mixed/single class bookings.
        String tempPaymentMethod = ""; // Will be determined after payment process.

        // Loop to book each requested seat individually.
        while (bookedCount < totalToBook) {

            // Recalculate available seats for each class based on current 'bookedSeats'.
            List<Integer> availableBusiness = new ArrayList<>();
            List<Integer> availableEconomy = new ArrayList<>();

            // Populate available seat lists by checking all seat numbers from 1 to
            // TOTAL_SEATS.
            for (int i = 1; i <= TOTAL_SEATS; i++) {

                if (!bookedSeats.contains(i)) { // If seat 'i' is not in the 'bookedSeats' list (i.e., it's available).
                    if (i <= BUSINESS_SEATS)
                        availableBusiness.add(i); // Add to business if within business seat range.
                    else
                        availableEconomy.add(i); // Add to economy otherwise.
                }
            }

            // Display available seats to the user.
            System.out.println("\nAvailable Business seats: " + availableBusiness);
            System.out.println("Available Economy seats: " + availableEconomy);

            // --- Seat Class Selection ---
            String selectedClassForSeat;

            while (true) { // Loop until a valid class (Business/Economy) is chosen.

                System.out.print("Choose class for seat " + (bookedCount + 1) + " (Business/Economy): ");
                selectedClassForSeat = input.nextLine().trim();

                if (selectedClassForSeat.equalsIgnoreCase("Business")
                        || selectedClassForSeat.equalsIgnoreCase("Economy"))
                    break; // Exit loop if valid class.

                System.out.println("Invalid class. Please enter 'Business' or 'Economy'.");
            }

            // Determine which list of available seats to use based on the selected class.
            List<Integer> currentAvailable = selectedClassForSeat.equalsIgnoreCase("Business") ? availableBusiness
                    : availableEconomy;

            // Check if there are actually any seats left in the chosen class.
            if (currentAvailable.isEmpty()) {
                System.out.println(
                        "No " + selectedClassForSeat + " seats left. Please choose another class or reduce quantity.");
                continue; // Skip to next iteration of outer loop (to re-ask for current seat's
                          // class/number).
            }

            // --- Seat Number Selection ---
            System.out.println("Available " + selectedClassForSeat + " seats: " + currentAvailable);
            System.out.print("Enter seat number: ");
            int seatNumber;

            try {
                seatNumber = Integer.parseInt(input.nextLine().trim());

                // Validate if the entered seat number is available in the chosen class.
                if (!currentAvailable.contains(seatNumber)) {
                    System.out.println("Invalid or already booked seat. Please choose from available seats.");
                    continue; // Skip to next iteration of outer loop (to re-ask for current seat's
                              // class/number).
                }

            } catch (NumberFormatException e) {
                System.out.println("Enter a valid seat number (a number).");
                continue; // Skip to next iteration if input is not a number.
            }

            // --- Gender Selection ---
            String gender;
            while (true) { // Loop until a valid gender (Male/Female) is chosen.

                System.out.print("Enter gender (Male/Female): ");
                gender = input.nextLine().trim();

                if (gender.equalsIgnoreCase("Male") || gender.equalsIgnoreCase("Female"))
                    break; // Exit loop if valid gender.

                System.out.println("Invalid gender. Please enter 'Male' or 'Female'.");
            }

            // --- Store Booking Details and Update Counters ---
            // Add the details of the newly booked seat to 'newBookings' (e.g.,
            // "10,Male,Economy").
            newBookings.add(seatNumber + "," + gender + "," + selectedClassForSeat);
            bookedSeats.add(seatNumber); // Add the seat number to the overall 'bookedSeats' list for this bus.
            bookedCount++; // Increment the counter for seats successfully booked in this session.

            // Calculate and add fare for the current seat.
            int fare = selectedClassForSeat.equalsIgnoreCase("Business") ? businessFares.get(busIndex)
                    : economyFares.get(busIndex);
            totalFare += fare;

            // Increment class-specific counters.
            if (selectedClassForSeat.equalsIgnoreCase("Business"))
                businessCount++;

            else
                economyCount++;

            System.out.println("Seat " + seatNumber + " (" + selectedClassForSeat + ") booked successfully.");
        } // End of while (bookedCount < totalToBook) loop

        // --- Determine Overall Class Type for the Ticket ---
        // This is for displaying "Business", "Economy", or "Mixed" on the final ticket.
        if (businessCount > 0 && economyCount > 0) {
            tempSelectedClass = "Mixed";

        } else if (businessCount > 0) {

            tempSelectedClass = "Business";
        } else {
            tempSelectedClass = "Economy";
        }

        // --- Display Fare Summary Before Payment ---
        if (businessCount > 0) {
            printFareDetails("Business", businessCount, busIndex); // Presumed helper method to show business fare.
        }

        if (economyCount > 0) {
            printFareDetails("Economy", economyCount, busIndex); // Presumed helper method to show economy fare.
        }

        // --- Payment Processing ---
        final String[] paymentMethodHolder = { "" }; // Stores the payment method once chosen.

        // Call the processPayment method. It returns true if payment is successful.
        if (processPayment(tempSelectedClass, busIndex, emailIndex, totalToBook, paymentMethodHolder)) {

            // --- Actions on Successful Payment ---
            saveBookingsToFile(busPlate, newBookings); // Save the new bookings to the bus-specific booking file.

            // Retrieve user's email and phone for the booking record.
            String userEmail = userId.get(emailIndex);
            String phone = phoneNumbers.get(emailIndex);

            // Generate a random alphanumeric booking ID. Length between 4 and 7 characters.
            int length = 4 + new Random().nextInt(4); // Generates 4, 5, 6, or 7
            String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            StringBuilder randomID = new StringBuilder();
            Random rand = new Random();

            for (int i = 0; i < length; i++) {
                randomID.append(characters.charAt(rand.nextInt(characters.length())));
            }

            String bookingID = "BKID-" + randomID.toString(); // Prefix with "BKID-"

            // Prepare the route string for the booking record.
            String route = startingPoints.get(busIndex) + " to " + destinationPoints.get(busIndex);

            // Generate a realistic random time for the bus departure (between 06:00 and 23:00).
            int hour = 6 + rand.nextInt(18); // Generates 6 to 23
            int minute = rand.nextBoolean() ? 0 : 30; // 00 or 30 minutes
            String amPm = (hour >= 12) ? "PM" : "AM";
            int displayHour = (hour % 12 == 0) ? 12 : hour % 12; // Convert 24-hour to 12-hour format
            String time = String.format("%02d:%02d %s", displayHour, minute, amPm);
            tempTime = time; // Store generated time for ticket printing.
            tempPaymentMethod = paymentMethodHolder[0]; // Store the actual payment method.

            // Write the complete booking record to a central booking history file.
            writeBookingRecord(userEmail, phone, bookingID, travelDate, tempTime, tempPaymentMethod, totalFare, route,
                    tempSelectedClass, totalToBook, busServices.get(busIndex));

            System.out.println("All bookings saved successfully.");

            // Call printTicket to display the final booking confirmation to the user.
            printTicket(tempUserEmail, bookingID, tempBusNum, tempBusService, tempRoute, tempTime, travelDate,
                    tempSelectedClass, totalToBook, tempPaymentMethod, totalFare);

        } else {
            // If payment failed, inform the user that booking was cancelled.
            System.out.println("Booking cancelled due to failed payment.");
        }
    }


    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: saveBookingsToFile (New)
    // ─────────────────────────────────────────────────────────────────────────────

    /**
     * Appends new booking details to the specific bus's seat booking file.
     * This method ensures that previously recorded bookings are preserved and new ones are added at the end.
     *
     * @param busPlate   The license plate of the bus, used to identify its booking file (e.g., "ABC-123.txt").
     * @param newBookings A List of Strings, where each string represents the details of a single new seat booking
     * (e.g., "10,Male,Economy"). These are the bookings to be saved.
     */
    public static void saveBookingsToFile(String busPlate, List<String> newBookings) {

        try (
            // Create a PrintWriter for convenient text writing (including automatic newlines with println).
            PrintWriter pw = new PrintWriter(
                // Create a FileWriter to write to the file named after the busPlate.
                // The 'true' argument (second parameter) is crucial here:
                // It tells FileWriter to open the file in 'append mode'.
                // This means new data will be added to the end of the existing file content,
                // rather than overwriting the entire file.
                new FileWriter(busPlate + ".txt", true)
            )
        ) {

            // Iterate through each booking string in the 'newBookings' list.
            // This is an enhanced for-loop, suitable for iterating over collections.

            for (String booking : newBookings) {
                // Write each individual booking string to the file, followed by a new line.
                // Each line in the file will correspond to one booked seat.
                pw.println(booking);
            }

        } catch (IOException e) {
            // Catch any IOException that might occur during file writing (e.g., permission denied, disk full).
            System.out.println("Error saving bookings.");
        }
    }


    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: Print Fare Details
    // ─────────────────────────────────────────────────────────────────────────────


    // Prints fare information using dynamic fare lists based on seat class and bus index
    public static void printFareDetails(String seatClass, int seatCount, int busIndex) {

        // Select fare per seat based on class type (Business or Economy)
        int farePerSeat = seatClass.equalsIgnoreCase("Business")
                ? businessFares.get(busIndex)
                : economyFares.get(busIndex);

        // Calculate total fare by multiplying fare per seat with seat count
        int total = farePerSeat * seatCount;

        // Display fare details to the user
        System.out.println("\nFare Details:");
        System.out.println("Class: " + seatClass);
        System.out.println("Seats: " + seatCount);
        System.out.println("Fare per seat: " + farePerSeat + " PKR");
        System.out.println("Total fare: " + total + " PKR");
    }


    // ---------------------------------------
    // Writes a booking record to "booking.txt" using provided user and booking details
    public static void writeBookingRecord(String email, String phone, String bookingID, LocalDate date, String time,
                                      String paymentMethod, int totalFare, String route,
                                      String selectedBusClass, int seatCount, String busService) {

        // Format date and route for consistent display in the record
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate = date.format(dateFormatter);
        // String formattedRoute = route.replace(" to ", " → ");
        String formattedRoute = route;

        // Construct the full booking record string
        String record = phone + " | " + bookingID + " | " + formattedDate + " | " + time +
                " | " + paymentMethod + " | " + totalFare + " PKR | " + formattedRoute + " | " +
                selectedBusClass + " | " + seatCount + " | " + busService;

        try {
            File file = new File("booking.txt");

            // Check if file exists and has content to decide if a newline is needed before appending
            boolean fileExistsAndNotEmpty = file.exists() && file.length() > 0;

            // Use try-with-resources for automatic closing of writers
            // FileWriter in append mode (true) to add to existing file
            try (FileWriter fw = new FileWriter(file, true);
                 BufferedWriter bw = new BufferedWriter(fw);
                 PrintWriter pw = new PrintWriter(bw)) {

                // Add a newline before the new record if the file already contains data
                if (fileExistsAndNotEmpty) {
                    pw.println();
                }

                pw.print(record); // Print the booking record to the file
                System.out.println("Booking record saved."); // Confirm save to user
            }

        } catch (IOException e) {
            // Handle any I/O errors during file writing
            System.out.println("Error saving booking record: " + e.getMessage());
        }
    }

    // ---------------------------------------
    // Processes payment based on selected class and seat count, and updates loyalty
    // points-
    public static boolean processPayment(String selectedBusClass, int busIndex, int emailIndex, int seatCount,
            String[] paymentMethodHolder) {

        // Calculate fare per seat and total fare based on seat class
        int farePerSeat = selectedBusClass.equalsIgnoreCase("Business")
                ? businessFares.get(busIndex)
                : economyFares.get(busIndex);
        int totalFare = farePerSeat * seatCount;

        // Display payment method options
        System.out.println("\nChoose a payment method:");
        System.out.println("1. Debit Card");
        System.out.println("2. Mobile Banking");
        System.out.println("3. Loyalty Points");
        System.out.println("4. Cash Payment");
        System.out.println("5. Credit Card");

        while (true) {
            System.out.print("Enter option (1 to 5): ");
            String inputChoice = input.nextLine().trim();

            switch (inputChoice) {

                case "1":
                    // Process debit card payment and update loyalty points
                    System.out.println("Paid " + totalFare + " PKR via Debit Card.");
                    pointsAddition(selectedBusClass, emailIndex);

                    // --- START OF CHANGES FOR printTicket METHOD CALL ---
                    paymentMethodHolder[0] = "Debit Card";
                    // --- END OF CHANGES FOR printTicket METHOD CALL ---
                    return true;

                case "2":
                    // Process mobile banking payment and update loyalty points
                    System.out.println("Paid " + totalFare + " PKR via Mobile Banking.");
                    pointsAddition(selectedBusClass, emailIndex);
                    // --- START OF CHANGES FOR printTicket METHOD CALL ---
                    paymentMethodHolder[0] = "Mobile Banking";
                    // --- END OF CHANGES FOR printTicket METHOD CALL ---
                    return true;

                case "3":
                    // Check and deduct loyalty points based on seat class
                    int requiredPoints = selectedBusClass.equalsIgnoreCase("Business") ? 4000 : 2000;
                    if (points.get(emailIndex) < requiredPoints) {
                        System.out.println("Not enough points. You need " + requiredPoints + " points.");
                        break;
                    }
                    pointsDeletion(selectedBusClass, emailIndex);
                    // --- START OF CHANGES FOR printTicket METHOD CALL ---
                    paymentMethodHolder[0] = "Loyalty Points";
                    // --- END OF CHANGES FOR printTicket METHOD CALL ---
                    return true;

                case "4":
                    // Inform user to pay by cash and update loyalty points
                    System.out.println("Please pay " + totalFare + " PKR in cash at the terminal.");
                    pointsAddition(selectedBusClass, emailIndex);
                    // --- START OF CHANGES FOR printTicket METHOD CALL ---
                    paymentMethodHolder[0] = "Cash Payment";
                    // --- END OF CHANGES FOR printTicket METHOD CALL ---
                    return true;

                case "5":
                    // Process credit card payment and update loyalty points
                    System.out.println("Paid " + totalFare + " PKR via Credit Card.");
                    pointsAddition(selectedBusClass, emailIndex);
                    // --- START OF CHANGES FOR printTicket METHOD CALL ---
                    paymentMethodHolder[0] = "Credit Card";
                    // --- END OF CHANGES FOR printTicket METHOD CALL ---
                    return true;

                default:
                    // Handle invalid option input
                    System.out.println("Invalid option. Try again.");
            }
        }
    }
    // ─────────────────────────────────────────────────────────────────────────────
    // SECTION: pointsAddition (New)
    // ─────────────────────────────────────────────────────────────────────────────

    // Adds loyalty points after a successful payment
    public static void pointsAddition(String selectedBusClass, int emailIndex) {
        try {
            int addition = selectedBusClass.equalsIgnoreCase("Business") ? 400 : 200;
            points.set(emailIndex, points.get(emailIndex) + addition);
            System.out.println("Loyalty points added: " + addition);
        } catch (Exception e) {
            System.out.println("Error adding points.");
        }
    }

    // Deducts loyalty points when paying with them
    public static void pointsDeletion(String selectedBusClass, int emailIndex) {
        try {
            int deduction = selectedBusClass.equalsIgnoreCase("Business") ? 4000 : 2000;
            points.set(emailIndex, points.get(emailIndex) - deduction);
            System.out.println("Points redeemed: " + deduction);
        } catch (Exception e) {
            System.out.println("Error handling points.");
        }
    }

    // --- START OF NEW METHOD: printTicket ---
    /**
     * Prints a formatted bus ticket with booking details.
     *
     * @param userEmail     The email of the user who booked the ticket.
     * @param bookingId     The unique booking ID.
     * @param busNum        The bus number.
     * @param busService    The name of the bus service (e.g., "Daewoo Express").
     * @param route         The travel route (e.g., "Lahore to Islamabad").
     * @param time          The departure time.
     * @param travelDate    The date of travel.
     * @param selectedClass The selected class (Economy, Business, or Mixed).
     * @param seatCount     The number of seats booked.
     * @param paymentMethod The method used for payment.
     * @param totalFare     The total fare paid for the booking.
     */
    public static void printTicket(String userEmail, String bookingId, String busNum, String busService,
            String route, String time, LocalDate travelDate, String selectedClass, int seatCount,
            String paymentMethod, int totalFare) {

        // Format the travel date for display in dd-MM-yyyy format
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String formattedTravelDate = travelDate.format(dateFormatter);

        // Print a formatted ticket containing all relevant booking details
        System.out.println("\n\n" +
                "----------------------------------------------------");
        System.out.println("                    E-BUS TICKET                    ");
        System.out.println("----------------------------------------------------");
        System.out.println(String.format("  %-18s: %s", "Booking ID", bookingId));
        System.out.println(String.format("  %-18s: %s", "User Email", userEmail));
        System.out.println(String.format("  %-18s: %s", "Bus Service", busService));
        System.out.println(String.format("  %-18s: %s", "Bus Number", busNum));
        System.out.println(String.format("  %-18s: %s", "Route", route));
        System.out.println(String.format("  %-18s: %s", "Travel Date", formattedTravelDate));
        System.out.println(String.format("  %-18s: %s", "Departure Time", time));
        System.out.println(String.format("  %-18s: %s", "Class", selectedClass));
        System.out.println(String.format("  %-18s: %d", "Seats Booked", seatCount));
        System.out.println(String.format("  %-18s: %s", "Payment Method", paymentMethod));
        System.out.println(String.format("  %-18s: Rs. %d", "Total Fare", totalFare));
        System.out.println("----------------------------------------------------");
        System.out.println("  Thank you for choosing " + busService + "! Safe travels!");
        System.out.println("----------------------------------------------------\n");
    }
    // --- END OF NEW METHOD: printTicket ---

    public static void showBookingHistory(String userPhone) {
        String fileName = "booking.txt"; // Booking data file
        boolean found = false;

        // Display heading for the user's booking history
        System.out.println("\n======= Booking History for " + userPhone + " =======");

        // Attempt to read the booking data file
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;

            // Read file line by line
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(" \\| ");

                // Check if the booking belongs to the specified phone number
                if (parts.length >= 10 && parts[0].trim().equals(userPhone)) {
                    found = true;

                    // Print formatted booking details
                    System.out.println("--------------------------------------");
                    System.out.println("Booking ID:     " + parts[1].trim());
                    System.out.println("Date:           " + parts[2].trim());
                    System.out.println("Time:           " + parts[3].trim());
                    System.out.println("Payment Method: " + parts[4].trim());
                    System.out.println("Fare:           " + parts[5].trim());
                    System.out.println("Route:          " + parts[6].trim());
                    System.out.println("Class:          " + parts[7].trim());
                    System.out.println("Seats Booked:   " + parts[8].trim());
                    System.out.println("Bus Service:    " + parts[9].trim());
                }
            }

            // Inform user if no matching booking was found
            if (!found) {
                System.out.println("No bookings found for this number.");
            }

        } catch (IOException e) {
            // Handle file reading errors
            System.err.println("Error reading booking.txt");
            e.printStackTrace();
        }
    }

}