
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int choice;


System.out.println("\u001b[36m");
System.out.println("\r\n" + //
        "██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗    ████████╗ ██████╗ \r\n" + //
        "██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝    ╚══██╔══╝██╔═══██╗\r\n" + //
        "██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗         ██║   ██║   ██║\r\n" + //
        "██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝         ██║   ██║   ██║\r\n" + //
        "╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗       ██║   ╚██████╔╝\r\n" + //
        " ╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝       ╚═╝    ╚═════╝ \r\n" + //
        "                                                                                    \r\n" + //
        "");
        System.out.println("");
System.out.println("\r\n" + //
        "██████╗ ██╗   ██╗███████╗    ███╗   ███╗ █████╗ ███╗   ██╗ █████╗  ██████╗ ███████╗███╗   ███╗███████╗███╗   ██╗████████╗\r\n" + //
        "██╔══██╗██║   ██║██╔════╝    ████╗ ████║██╔══██╗████╗  ██║██╔══██╗██╔════╝ ██╔════╝████╗ ████║██╔════╝████╗  ██║╚══██╔══╝\r\n" + //
        "██████╔╝██║   ██║███████╗    ██╔████╔██║███████║██╔██╗ ██║███████║██║  ███╗█████╗  ██╔████╔██║█████╗  ██╔██╗ ██║   ██║   \r\n" + //
        "██╔══██╗██║   ██║╚════██║    ██║╚██╔╝██║██╔══██║██║╚██╗██║██╔══██║██║   ██║██╔══╝  ██║╚██╔╝██║██╔══╝  ██║╚██╗██║   ██║   \r\n" + //
        "██████╔╝╚██████╔╝███████║    ██║ ╚═╝ ██║██║  ██║██║ ╚████║██║  ██║╚██████╔╝███████╗██║ ╚═╝ ██║███████╗██║ ╚████║   ██║   \r\n" + //
        "╚═════╝  ╚═════╝ ╚══════╝    ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚═╝     ╚═╝╚══════╝╚═╝  ╚═══╝   ╚═╝   \r\n" + //
        "                                                                                                                         \r\n" + //
        "");
System.out.println("\u001b[0m");

        while (true) {
            System.out.println("\n==============================");
            System.out.println("|       MAIN MENU            |");
            System.out.println("==============================");
            System.out.println("| 1. Admin Panel             |");
            System.out.println("| 2. User Panel              |");
            System.out.println("| 0. Exit                    |");
            System.out.println("==============================");
            System.out.print("Enter your choice: ");

            // Input validation
            if (!input.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); // Clear invalid input
                continue;
            }

            choice = input.nextInt();

            switch (choice) {
                case 1:
                    AdminModule.run();
                    break;
                case 2:
                    FinalUserModule.run();
                    break;
                case 0:
                    System.out.println("Exiting application. Goodbye!");
                    input.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please choose 0, 1 or 2.");
            }
        }
    }
}
